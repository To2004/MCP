"""
run_all.py — the whole gateway, in the order it's meant to run.

Three phases, printed as it goes:

    PHASE 1  static scan        → the artifact (cells[asset][tool] ceilings)
    PHASE 2  app-context compile → each app's declared ops/assets, into the store
    PHASE 3  runtime scoring     → score live calls against artifact + baseline

Phases 1 and 2 are OFFLINE (run once, or when the MCP / apps change). Phase 3 is
per-call. This script does all three so the sequence is visible in one place.

It is resilient: if your real static-pipeline and app-context modules are
importable it uses them; otherwise it falls back to an inline artifact and direct
app-context so the runtime half still runs. It prints which path it took.

Run:  python run_all.py
Edit the IMPORTS block if your package paths differ.
"""

from __future__ import annotations

# ============================================================ IMPORTS (edit to match your tree)
from mcp_security.gateway import GatewayConfig, DynamicScorer
from mcp_security.gateway.artifact import StaticArtifact
from mcp_security.gateway.state import make_store
from mcp_security.gateway.state.base import AppContext


def rule(title: str) -> None:
    print("\n" + "=" * 78 + f"\n{title}\n" + "=" * 78)


# ============================================================ PHASE 1 · STATIC SCAN → ARTIFACT
rule("PHASE 1 · static scan  →  artifact (offline, once)")

artifact = None
try:
    # Preferred: your real static pipeline. Adjust the import to your module.
    from static_pipeline import Tool, Asset, ServerInput, run_static_scan  # type: ignore

    fs = ServerInput(
        server="fs:corp", kind="filesystem",
        tools=[
            Tool("read_file", "Returns the full text content of a file."),
            Tool("read_multiple_files", "Reads several files in one call.",
                 input_schema={"properties": {"paths": {"type": "array"}}, "required": ["paths"]}),
            Tool("write_file", "Creates or completely overwrites a file."),
            Tool("move_file", "Moves or renames a file.",
                 input_schema={"properties": {"source": {"type": "string"},
                                              "destination": {"type": "string"}}}),
            Tool("list_directory", "Lists the immediate contents of a directory."),
        ],
        assets=[
            Asset("README.md", "Public project readme.", org_priority="public",
                  tools=("read_file", "list_directory")),
            Asset("payslips.csv", "Employee payroll, regulated PII.", org_priority=4,
                  tools=("read_file", "read_multiple_files", "write_file", "move_file")),
            Asset("private_key.pem", "Private cryptographic key.", org_priority=5,
                  tools=("read_file", "write_file", "move_file")),
        ],
    )
    artifact = StaticArtifact.from_table(run_static_scan(fs, use_llm=False), version="run-all")
    print("  [real] ran static_pipeline.run_static_scan")
except Exception as e:  # noqa: BLE001 - fall back so the demo always runs
    print(f"  [fallback] static_pipeline not usable ({type(e).__name__}); using an inline artifact")
    TABLE = {
        "server": "fs:corp", "server_kind": "filesystem", "score_max": 125,
        "asset_ids": ["README.md", "payslips.csv", "private_key.pem"],
        "cells": {
            "README.md":       {"read_file": 3,  "write_file": 6,   "move_file": 4,   "list_directory": 2,    "read_multiple_files": 6},
            "payslips.csv":    {"read_file": 60, "write_file": 80,  "move_file": 75,  "list_directory": None,  "read_multiple_files": 90},
            "private_key.pem": {"read_file": 75, "write_file": 100, "move_file": 100, "list_directory": None,  "read_multiple_files": 100},
        },
        "bands": {
            "README.md":       {"read_file": "low",     "write_file": "low",     "move_file": "low"},
            "payslips.csv":    {"read_file": "high",    "write_file": "critical","move_file": "high",  "read_multiple_files": "critical"},
            "private_key.pem": {"read_file": "critical","write_file": "critical","move_file": "critical","read_multiple_files": "critical"},
        },
        "tool_input_ranking": {"read_multiple_files": {"inputs": [{"name": "paths", "critical_trigger": "20", "risk": 4}]}},
        "tool_impact_detail": {
            "read_file": {"primary_op": "read"}, "read_multiple_files": {"primary_op": "read"},
            "write_file": {"primary_op": "write"}, "move_file": {"primary_op": "move"},
            "list_directory": {"primary_op": "list"},
        },
    }
    artifact = StaticArtifact.from_table(TABLE, version="run-all-inline")

print(f"  artifact ready: {artifact.server} ({artifact.server_kind}), "
      f"{len(artifact.tools)} tools × {len(artifact.asset_ids)} assets, score_max={artifact.score_max}")


# ============================================================ PHASE 2 · APP-CONTEXT COMPILE
rule("PHASE 2 · app-context compile  →  baseline store (offline, once)")

config = GatewayConfig(state_backend="memory")
store = make_store(config)

APPS = {
    "backup-agent": "Backs up and lists public project files.",
    "payroll-app":  "Reads employee payslip records for reporting.",
}

try:
    from mcp_security.app_context.compiler import register_app  # type: ignore
    for app_id, purpose in APPS.items():
        register_app(store, app_id, purpose, artifact, use_llm=False)
    print("  [real] compiled app context via app_context.compiler")
except Exception as e:  # noqa: BLE001
    print(f"  [fallback] compiler not usable ({type(e).__name__}); declaring context directly")
    store.put_app_context(AppContext(app_id="backup-agent",
                                     expected_ops={"read", "list"},
                                     expected_assets={"README.md"},
                                     purpose=APPS["backup-agent"]))
    store.put_app_context(AppContext(app_id="payroll-app",
                                     expected_ops={"read"},
                                     expected_assets={"payslips.csv"},
                                     purpose=APPS["payroll-app"]))

for app_id in APPS:
    ctx = store.get_app_context(app_id)
    if ctx:
        print(f"  {app_id}: ops={sorted(ctx.expected_ops)} assets={sorted(ctx.expected_assets)}")


# ============================================================ PHASE 3 · RUNTIME SCORING
rule("PHASE 3 · runtime scoring  →  per live call")

scorer = DynamicScorer(artifact, config, store=store)


def fire(app, tool, args, note=""):
    d = scorer.score(app, tool, args)
    print(f"\n• {app} → {tool}({args})")
    if note:
        print(f"  expect: {note}")
    print("  " + d.explain())
    return d


# a spread of calls, each probing one behaviour
fire("rogue-agent", "read_file", {"path": "private_key.pem"},
     "first-ever + unknown app + critical ceiling → DROP")

fire("rogue-agent", "move_file",
     {"source": "sensitive/security/private_key.pem", "destination": "public/leak.txt"},
     "sensitive→public flow → exposure STRONG + hard DROP floor")

fire("backup-agent", "read_file", {"path": "payslips.csv"},
     "asset outside declared scope → anomaly raises")

print("\n--- backup-agent reads README repeatedly (low ceiling, in-scope) ---")
print("    novelty relaxes deviation (1.6→1.3→1.0), then bias builds from n≥5:")
for i in range(14):
    d = scorer.score("backup-agent", "read_file", {"path": "README.md"})
    n = store.count("backup-agent", "read_file", "README.md")
    print(f"  call {i+1:2}: {d.action.value:7} score={d.final_score:5.1f} "
          f"L={d.likelihood:.2f} bias={d.bias:.2f}  (seen={n})")

fire("payroll-app", "read_multiple_files",
     {"paths": ["payslips.csv"] + [f"hr/f{i}.csv" for i in range(39)]},
     "40 ≥ 20 paths → escalation amplifier fires")

rule("done — phases 1→2→3 complete")
