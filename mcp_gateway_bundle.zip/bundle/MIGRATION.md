# One-Sided Likelihood Rework — migration notes

Reworked so the runtime layer can only ever RAISE risk; the single downward
force is a separate, floored `bias`. This removes the double-count and the
"reward for staying in-scope" that let the old two-sided model be discounted
below threshold. Formula is now:

    final = ceiling × likelihood × escalation × bias
    likelihood = deviation × anomaly × exposure   (each ≥ 1.0, capped at cap)
    escalation ≥ 1.0 (unchanged — was already one-sided)
    bias ∈ [floor, 1]  — the ONLY term below 1.0, floored by static band

## Files changed
- **config.py** — replaced `decay_k`, `deviation_floor`, `anomaly_in_scope/out/
  unknown`, `exposure_benign` with one shared tier scheme (`factor_normal/
  elevated/strong`, `likelihood_cap`) plus the relocated bias knobs
  (`bias_decay_k`, `bias_floor`, `bias_min_observations`).
- **deviation.py** — was a decaying discount (1.0→floor). Now a one-sided novelty
  alarm keyed on (app, tool, ASSET): unseen→strong, rare→elevated, else 1.0.
  The routine discount it used to carry now lives only in `bias`.
- **anomaly.py** — in-scope was 0.25 (a reward). Now in-scope = 1.0 (no alarm);
  one signal → elevated, both op+asset out → strong.
- **exposure.py** — benign was 0.3 (discount); the DROP floor was doing all the
  work. Now benign = 1.0, exfil = strong + DROP floor (multiplier and floor
  agree). Disguise/sensitive-touch → elevated.
- **engine.py** — caps the likelihood product at `config.likelihood_cap`.
- **scorer.py** — adds `_bias()` (floored learned discount, trust-gated, and 1.0
  when the asset is unresolved so an unpinnable call is never discounted) and
  multiplies it in: `final = ceiling × L × escalation × bias`.
- **decision.py** — `Decision` gains a `bias` field, shown in audit + explain.
- **escalation.py** — unchanged (already a ≥1.0 amplifier).

## Knob mapping (old → new)
- deviation_floor{critical:0.6,…}   → bias_floor{critical:0.75,…} (relocated)
- anomaly_in_scope 0.25             → factor_normal 1.0 (no reward)
- anomaly_out_of_scope 1.0          → factor_elevated 1.3 / factor_strong 1.6
- exposure_benign 0.3               → factor_normal 1.0
- decay_k 0.7 (deviation decay)     → bias_decay_k 0.15 (bias only)

## Behaviour preserved
- The safety asymmetry (dangerous cells never normalised) — now via bias_floor.
- Exfil hard-stop via the DROP floor.
- Only allowed/degraded calls train the baseline.
- The `novel = not seen_tool(app,tool)` decision-floor remains as a coarse
  cold-start backstop; the per-(app,tool,asset) novelty now lives in deviation,
  so consider whether you still want both (they no longer double-count the SCORE,
  but both can raise the ACTION on a first call).

## Not included
`likelihood/base.py` (ScoringContext + LikelihoodFactor) was not in the batch, so
it's untouched — the rework relies only on its existing fields. If you want, send
it and I'll confirm nothing there needs adjusting.
