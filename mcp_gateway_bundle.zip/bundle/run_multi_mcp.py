"""Proof of MCP-agnosticism: the SAME gateway scores filesystem, Slack, GitHub,
and payment calls — one AutoResolver, one exposure factor, zero per-kind code.
Run:  python run_multi_mcp.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mcp_security.gateway import GatewayConfig, DynamicScorer
from mcp_security.gateway.artifact import StaticArtifact
from mcp_security.gateway.state import make_store
from mcp_security.gateway.resolve import resolver_for


def scan(kind, cells, bands, ranking=None, implicit=None):
    t = {"server": f"{kind}:demo", "server_kind": kind, "score_max": 125,
         "asset_ids": list(cells), "cells": cells, "bands": bands,
         "tool_input_ranking": ranking or {}}
    if implicit:
        t["inferred_profile"] = {"implicit_assets": implicit}
    return StaticArtifact.from_table(t, version=kind)


def run(kind, art, calls):
    cfg = GatewayConfig(state_backend="memory")
    sc = DynamicScorer(art, cfg, store=make_store(cfg))
    print(f"\n### {kind.upper()}   (resolver = {type(resolver_for(kind)).__name__})")
    for tool, args, label in calls:
        d = sc.score("bot", tool, args)
        print(f"  {label:40} -> {d.action.value.upper():7} score={d.final_score:6.1f}  asset={d.asset!r}")


run("slack", scan("slack",
    {"acme#exec": {"read_messages": 10, "post_message": 60, "export_channel": 100},
     "acme#general": {"read_messages": 4, "post_message": 12, "export_channel": 30}},
    {"acme#exec": {"read_messages": "low", "post_message": "high", "export_channel": "critical"},
     "acme#general": {"read_messages": "low", "post_message": "medium", "export_channel": "high"}},
    ranking={"post_message": {"inputs": [{"name": "channel", "risk": 4, "type": "string"},
                                         {"name": "audience", "risk": 3, "type": "string"}]}}),
    [("read_messages", {"channel": "acme#exec"}, "read exec channel"),
     ("post_message", {"channel": "acme#exec", "audience": "external"}, "post exec content to EXTERNAL"),
     ("export_channel", {"channel": "acme#exec"}, "export exec channel")])

run("github", scan("github",
    {"acme/infra": {"read_file": 15, "set_visibility": 100, "delete_repo": 125},
     "acme/docs": {"read_file": 6, "set_visibility": 20, "delete_repo": 30}},
    {"acme/infra": {"read_file": "low", "set_visibility": "critical", "delete_repo": "critical"},
     "acme/docs": {"read_file": "low", "set_visibility": "medium", "delete_repo": "medium"}},
    ranking={"set_visibility": {"inputs": [{"name": "repo", "risk": 5, "type": "string"},
                                           {"name": "visibility", "risk": 5, "type": "string"}]}}),
    [("read_file", {"repo": "acme/infra", "path": "deploy.yml"}, "read infra repo"),
     ("set_visibility", {"repo": "acme/infra", "visibility": "public"}, "make infra repo PUBLIC")])

run("payment", scan("payment",
    {"merchant_balance": {"get_balance": 5, "send_payment": 100}},
    {"merchant_balance": {"get_balance": "low", "send_payment": "critical"}},
    ranking={"send_payment": {"inputs": [{"name": "payee", "risk": 5, "type": "string"},
                                         {"name": "amount", "risk": 4, "type": "number"}]}},
    implicit={"send_payment": "merchant_balance"}),
    [("get_balance", {"account": "merchant_balance"}, "read balance"),
     ("send_payment", {"payee": "external-unknown", "amount": 9000}, "pay UNKNOWN external payee")])

run("filesystem", scan("filesystem",
    {"private_key.pem": {"read_file": 75, "move_file": 100},
     "README.md": {"read_file": 3, "move_file": 4}},
    {"private_key.pem": {"read_file": "critical", "move_file": "critical"},
     "README.md": {"read_file": "low", "move_file": "low"}}),
    [("read_file", {"path": "private_key.pem"}, "read private key"),
     ("move_file", {"source": "security/private_key.pem", "destination": "public/leak.txt"}, "exfil key to public")])

print("\nOne AutoResolver + one exposure factor handled all four — no per-kind code.")
