# MCP Misuse-Scoring Gateway — complete runnable bundle

Everything needed to run the gateway, assembled into one package. Verified: the
whole tree byte-compiles and both entry points run end-to-end.

## Run it

From THIS folder (the one containing `mcp_security/`):

```bash
python run_all.py       # the 3 phases, in order, with banners
python scenarios/filesystem_session.py   # realistic session (see scenarios/README.md)
```

No install needed — the scripts import `mcp_security` as a local package, so run
them from here (or add this folder to PYTHONPATH). Requires Python 3.10+.

## MCP-agnostic — works on any MCP

The gateway is not filesystem-specific. Asset resolution and exposure both adapt
to the MCP kind with no per-kind code:

- **`resolve.py`** derives which argument names the asset from the scan's
  `tool_input_ranking` (highest-risk non-destination input), then matches its
  value against the asset ids (with hierarchical parent inheritance for paths
  `a/b/c`, repos `org/repo`, channels `ws#chan`). One `AutoResolver` handles
  filesystem, Slack, GitHub, payment, Google, … A per-kind override (e.g.
  `SqlResolver`, which must pull a table out of a raw query string) is registered
  only when a domain needs logic the scan can't express.
- **`exposure.py`** selects its sensitive/public zone tests by `server_kind`
  (Slack external audiences, GitHub public visibility, payment unknown payees,
  Google external shares, filesystem public paths). A scan may override via
  `inferred_profile.exposure_zones`.

See it for yourself:

```bash
python run_multi_mcp.py
```

scores the same gateway across Slack, GitHub, payment, and filesystem — e.g. a
Slack "post exec content to an external audience" and a GitHub "make infra repo
public" both DROP on the exposure factor, with one resolver and zero per-kind
code.

## Layout

```
mcp_security/
  gateway/                 the runtime scoring gateway
    config.py              GatewayConfig — all tunable knobs        [REWORKED]
    artifact.py            StaticArtifact — loads/validates the scan
    resolve.py             AssetResolver — auto-derives the asset locator from
                           the scan; MCP-agnostic (filesystem/slack/github/…)  [REWORKED]
    scorer.py              DynamicScorer — orchestrates a call       [REWORKED]
    decision.py            Decision + Action + banding               [REWORKED]
    interceptor.py         GatewayMiddleware — call interception + enforcement
    audit.py               structured decision logging
    likelihood/
      base.py              ScoringContext + LikelihoodFactor       [RECONSTRUCTED]
      deviation.py         novelty alarm (one-sided)                 [REWORKED]
      anomaly.py           in/out-of-scope (one-sided)               [REWORKED]
      exposure.py          sensitive→public flow (one-sided)         [REWORKED]
      escalation.py        parameter amplifier (unchanged)
      engine.py            composes the factors, caps likelihood     [REWORKED]
    state/
      base.py              BaselineStore ABC + AppContext
      memory.py            in-memory store (dev/tests)
      redis.py             redis store (production)
      __init__.py          make_store factory                     [RECONSTRUCTED]
  app_context/             offline: compile an app's declared scope
    compiler.py  prompts.py
  static_pipeline/         offline: the static scan that builds the artifact
    pipeline.py  model.py  builders.py  client.py  classifier_schemas.py
    run_pipeline.py

run_all.py         3-phase orchestrator (static → app-context → runtime)
dummy_calls.py     runtime scenarios only
MIGRATION.md       what the one-sided rework changed and why
```

## What is [REWORKED], [RECONSTRUCTED], and original

**[REWORKED]** (7 files) — changed to the corrected one-sided model: likelihood
factors can only RAISE the score (each ≥ 1.0, product capped at 3.0), and the one
downward force is a separate learned `bias` floored by band so a dangerous cell
can never be normalised. See MIGRATION.md for the knob-by-knob mapping. These
replace your originals; diff them if you want to review each change.

**[RECONSTRUCTED]** (2 files) — `likelihood/base.py` and `state/__init__.py` were
not in the files provided, so they were rebuilt to exactly match how the rest of
the package imports and uses them. Each carries a header saying so. If you still
have the originals, drop them back in — the reconstructed interfaces are the
contract everything else relies on, so they should match.

**Everything else** — your uploaded files, unchanged, in their correct package
homes.

## Note on run_all.py phases 1–2

`run_all.py` tries your real static pipeline and app-context compiler first, and
falls back to an inline artifact / direct app-context if their exact entry points
(`static_pipeline.run_static_scan`, `app_context.compiler.register_app`) aren't
importable — printing `[real]` or `[fallback]` so you can see which ran. The
runtime scoring (phase 3) always uses your real reworked code. The uploaded
`run_gateway_e2e.py` imports a top-level `static_pipeline` with
`Tool/Asset/ServerInput/run_static_scan`; the pipeline module here exposes
`InferenceScoringPipeline`, so if those thin wrappers live elsewhere in your
tree, add them to `static_pipeline/__init__.py`.
```
