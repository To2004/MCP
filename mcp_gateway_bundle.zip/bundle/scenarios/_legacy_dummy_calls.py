"""
Dummy calls to exercise the gateway — self-contained, no static pipeline or MCP
transport required. Builds a tiny inline artifact (a filesystem MCP with three
assets), stands up the scorer, and fires a spread of calls that each target a
specific behaviour of the one-sided model.

Run from your package root (so `mcp_security...` imports resolve):

    python dummy_calls.py

If your import paths differ, edit the IMPORTS block below to match your tree.
"""

# ----------------------------------------------------------------------------- IMPORTS
# Adjust these to wherever the gateway package lives in your project.
from mcp_security.gateway import GatewayConfig, DynamicScorer
from mcp_security.gateway.artifact import StaticArtifact
from mcp_security.gateway.state import make_store
from mcp_security.gateway.state.base import AppContext   # for declaring app scope

# ----------------------------------------------------------------------------- 1 · INLINE ARTIFACT
# A minimal static matrix: cells[asset][tool] = ceiling, plus bands + score_max.
# These numbers mimic the filesystem scan (private_key.pem is the crown jewel).
TABLE = {
    "server": "fs:dummy",
    "server_kind": "filesystem",
    "score_max": 125,
    "asset_ids": ["README.md", "payslips.csv", "private_key.pem"],
    "cells": {
        # asset            read_file  write_file  move_file  list_directory  read_multiple_files
        "README.md":        {"read_file": 3,  "write_file": 6,  "move_file": 4,  "list_directory": 2,  "read_multiple_files": 6},
        "payslips.csv":     {"read_file": 60, "write_file": 80, "move_file": 75, "list_directory": None, "read_multiple_files": 90},
        "private_key.pem":  {"read_file": 75, "write_file": 100,"move_file": 100,"list_directory": None, "read_multiple_files": 100},
    },
    "bands": {
        "README.md":       {"read_file": "low",    "write_file": "low",    "move_file": "low",    "list_directory": "low"},
        "payslips.csv":    {"read_file": "high",   "write_file": "critical","move_file": "high",   "read_multiple_files": "critical"},
        "private_key.pem": {"read_file": "critical","write_file": "critical","move_file": "critical","read_multiple_files": "critical"},
    },
    # optional: lets the escalation factor read per-parameter triggers
    "tool_input_ranking": {
        "read_multiple_files": {"inputs": [{"name": "paths", "critical_trigger": "20", "risk": 4}]},
    },
    # optional: primary op per tool, used by the anomaly factor
    "tool_impact_detail": {
        "read_file": {"primary_op": "read"},
        "read_multiple_files": {"primary_op": "read"},
        "write_file": {"primary_op": "write"},
        "move_file": {"primary_op": "move"},
        "list_directory": {"primary_op": "list"},
    },
}

artifact = StaticArtifact.from_table(TABLE, version="dummy-v1")

# ----------------------------------------------------------------------------- 2 · GATEWAY
config = GatewayConfig(state_backend="memory")
store = make_store(config)
scorer = DynamicScorer(artifact, config, store=store)

# ----------------------------------------------------------------------------- 3 · DECLARE APP SCOPE (offline)
# The anomaly factor checks calls against what an app is declared to do. Here we
# set it directly; in production this comes from the offline app-context compiler.
store.put_app_context(AppContext(
    app_id="payroll-app",
    expected_ops={"read"},
    expected_assets={"payslips.csv"},
    purpose="Reads employee payslip records for reporting.",
))
store.put_app_context(AppContext(
    app_id="backup-agent",
    expected_ops={"read", "list"},
    expected_assets={"README.md"},
    purpose="Backs up and lists public project files.",
))
# note: "rogue-agent" is intentionally NOT declared → treated as unknown-app.

# ----------------------------------------------------------------------------- 4 · HELPER
def fire(app, tool, args, note=""):
    d = scorer.score(app, tool, args)
    print(f"\n• {app} → {tool}({args})")
    if note:
        print(f"  expect: {note}")
    print("  " + d.explain())
    return d

# ============================================================================= SCENARIOS
print("=" * 78)
print("DUMMY CALLS — each targets one behaviour of the one-sided model")
print("=" * 78)

# 1. First-ever call by a never-seen agent on the crown jewel → novelty + high ceiling
fire("rogue-agent", "read_file", {"path": "private_key.pem"},
     "first-ever + unknown app + critical ceiling → DROP")

# 2. The classic exfil move: sensitive source → public destination
fire("rogue-agent", "move_file",
     {"source": "sensitive/security/private_key.pem", "destination": "public/leak.txt"},
     "sensitive→public flow → exposure STRONG + hard DROP floor")

# 3. Out-of-scope read: backup-agent (declared: README only) reaches payroll
fire("backup-agent", "read_file", {"path": "payslips.csv"},
     "asset outside declared scope → anomaly raises → at least DEGRADE")

# 4. In-scope, repeated, on a LOW-ceiling asset — the one case that can settle.
#    (A high-ceiling cell that starts in DROP can never learn down: dropped calls
#    don't train, by design. Learning is only visible where calls are allowed.)
print("\n--- backup-agent reads README repeatedly (low ceiling, in-scope) ---")
print("    watch: novelty relaxes deviation (1.6→1.3→1.0), then bias builds from n≥5 ---")
for i in range(14):
    d = scorer.score("backup-agent", "read_file", {"path": "README.md"})
    n = store.count("backup-agent", "read_file", "README.md")
    print(f"  call {i+1:2}: {d.action.value:7} score={d.final_score:5.1f} "
          f"L={d.likelihood:.2f} bias={d.bias:.2f}  (seen={n})")

# 5. Bulk fan-out: 40-path read → parameter escalation amplifier fires.
fire("payroll-app", "read_multiple_files",
     {"paths": ["payslips.csv"] + [f"hr/f{i}.csv" for i in range(39)]},
     "40 ≥ 20 paths → escalation ≥ 1.5 amplifies the score")

# 6. Genuinely benign: public readme, low ceiling, in-scope
fire("backup-agent", "read_file", {"path": "README.md"},
     "low ceiling + in-scope → ALLOW (after novelty relaxes)")

# 7. Unresolved asset: a path that maps to no cell → conservative worst-ceiling,
#    and bias pinned to 1.0 (an unpinnable call is never discounted)
fire("payroll-app", "write_file", {"path": "some/unknown/place.txt", "content": "x"},
     "asset unresolved → worst ceiling for write_file, bias stays 1.0")

print("\n" + "=" * 78)
print("done — tweak apps/tools/args above to probe other cells")
print("=" * 78)
