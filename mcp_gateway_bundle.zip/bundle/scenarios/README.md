# Realistic scenario sessions

Each script builds a real-ish static artifact for one MCP server, registers the
agents that call it (with their declared purpose), and replays traffic that reads
like a real working session — normal work that drifts into an incident. Every
printed score/decision is exactly what the gateway returns; the annotations were
checked against the real output.

    python scenarios/filesystem_session.py   # corp document server
    python scenarios/slack_session.py        # company workspace
    python scenarios/github_session.py       # engineering org
    python scenarios/payment_session.py      # merchant payments backend

What they demonstrate (same gateway, four different MCP kinds — no domain code):

- **filesystem** — routine agents settle to ALLOW as the gateway learns their
  baseline; a prompt-injected support bot is degraded then blocked as it leaves
  its lane; the SSH key / vault token stay blocked even for a security-scoped bot.
- **slack** — routine posters flow; a compromised helpdesk bot is blocked reading
  private HR/exec channels, leaking to an external audience, and bulk-exporting.
- **github** — dev traffic flows; a compromised contractor is blocked making infra
  public and deleting production; a high-value in-scope merge is held for a human.
- **payment** — reads and known-customer refunds flow; a payout to an unknown
  external payee is blocked, with the protected asset (merchant balance) resolved
  implicitly from the scan.

Two honest behaviours these make visible:

- A high/critical-ceiling cell that starts above the DROP threshold is blocked on
  the first call and — because dropped calls never train the baseline — cannot
  "learn its way" to allowed. This is deliberate: dangerous operations require a
  human, and a blocked (likely-malicious) call must never teach the model it is
  routine. Learning down to ALLOW is visible only on lower-ceiling cells.
- A first-ever call by any agent is never silently allowed (at least DEGRADE),
  even when the arithmetic is low.
