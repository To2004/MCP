"""
Filesystem MCP — a corporate document server, one working session.

Cast (real service identities, each with a declared purpose):
  • ci-runner       — CI/CD build agent; reads source, writes build artifacts
  • analytics-svc   — nightly analytics; reads project reports, writes summaries
  • support-copilot — customer-support assistant; reads public docs only

Everything printed is exactly what the gateway returns. The session shows:
  1. routine agents settle to ALLOW as the gateway learns their baseline;
  2. a prompt-injected support bot drifts out of scope → degraded then blocked;
  3. crown-jewel cells (SSH key, vault token) are hard-blocked for EVERY agent —
     an autonomous agent never reads them, by design, however "in scope" it is.
"""

from _harness import Session, header, note

TABLE = {
    "server": "fs:corp-docs",
    "server_kind": "filesystem",
    "score_max": 125,
    "asset_ids": [
        "docs/", "docs/handbook.md", "docs/faq.md",
        "src/", "src/app/server.py", "src/app/auth.py",
        "reports/", "reports/2026-q1.csv",
        "sensitive/", "sensitive/financials/", "sensitive/financials/payroll_2026_03.csv",
        "sensitive/security/", "sensitive/security/id_rsa", "sensitive/security/vault_token",
    ],
    "cells": {
        "docs/handbook.md":  {"read_file": 3, "write_file": 8, "move_file": 6, "list_directory": 2},
        "docs/faq.md":       {"read_file": 3, "write_file": 8, "move_file": 6},
        "docs/":             {"read_file": 3, "list_directory": 2, "write_file": 8},
        "src/app/server.py": {"read_file": 12, "write_file": 30, "move_file": 24, "edit_file": 30},
        "src/app/auth.py":   {"read_file": 20, "write_file": 48, "move_file": 40, "edit_file": 48},
        "src/":              {"read_file": 12, "list_directory": 8, "write_file": 30},
        "reports/2026-q1.csv": {"read_file": 24, "write_file": 40, "move_file": 32},
        "reports/":          {"read_file": 20, "list_directory": 10, "write_file": 40},
        "sensitive/financials/payroll_2026_03.csv":
                             {"read_file": 60, "write_file": 80, "move_file": 75},
        "sensitive/financials/": {"read_file": 60, "list_directory": 40, "write_file": 80},
        "sensitive/security/id_rsa":      {"read_file": 100, "write_file": 125, "move_file": 125},
        "sensitive/security/vault_token": {"read_file": 100, "write_file": 125, "move_file": 125},
        "sensitive/security/": {"read_file": 100, "list_directory": 75, "write_file": 125},
        "sensitive/":        {"read_file": 60, "list_directory": 40},
    },
    "bands": {
        "docs/handbook.md":  {"read_file": "low", "write_file": "low", "move_file": "low"},
        "src/app/server.py": {"read_file": "low", "write_file": "medium", "edit_file": "medium"},
        "src/app/auth.py":   {"read_file": "medium", "write_file": "high", "edit_file": "high"},
        "reports/2026-q1.csv": {"read_file": "medium", "write_file": "high", "move_file": "high"},
        "sensitive/financials/payroll_2026_03.csv":
                             {"read_file": "high", "write_file": "critical", "move_file": "high"},
        "sensitive/security/id_rsa":      {"read_file": "critical", "write_file": "critical", "move_file": "critical"},
        "sensitive/security/vault_token": {"read_file": "critical", "write_file": "critical", "move_file": "critical"},
    },
    "tool_input_ranking": {
        "read_file":  {"inputs": [{"name": "path", "type": "string", "risk": 4}]},
        "move_file":  {"inputs": [{"name": "source", "type": "string", "risk": 5},
                                  {"name": "destination", "type": "string", "risk": 3}]},
        "read_multiple_files": {"inputs": [{"name": "paths", "type": "array", "critical_trigger": "20", "risk": 4}]},
    },
    "tool_impact_detail": {
        "read_file": {"primary_op": "read"}, "read_multiple_files": {"primary_op": "read"},
        "write_file": {"primary_op": "write"}, "edit_file": {"primary_op": "write"},
        "move_file": {"primary_op": "move"}, "list_directory": {"primary_op": "list"},
    },
}

s = Session(TABLE)
s.register("ci-runner", "Builds and tests the app; reads source, writes build output.",
           ops={"read", "list", "write"}, assets={"src/app/server.py", "src/app/auth.py", "src/"})
s.register("analytics-svc", "Nightly analytics; reads project reports, writes summaries.",
           ops={"read", "list", "write"}, assets={"reports/2026-q1.csv", "reports/"})
s.register("support-copilot", "Customer-support assistant; reads public docs only.",
           ops={"read", "list"}, assets={"docs/handbook.md", "docs/faq.md", "docs/"})

header("Filesystem MCP · fs:corp-docs", "Routine work settles to ALLOW; an injected bot is caught")

# ── Part 1: the gateway LEARNS a routine agent's baseline over a few calls ──
note("analytics-svc's first runs on the quarterly report — watch the gateway learn it")
for i in range(1, 9):
    d = s.scorer.score("analytics-svc", "read_file", {"path": "reports/2026-q1.csv"})
    tag = {"allow": "  ok ", "degrade": " warn", "drop": " BLOCK"}[d.action.value]
    extra = ""
    if i == 1:
        extra = "   ← first-ever call is never silently allowed"
    elif d.action.value == "allow" and i <= 3:
        extra = "   ← novelty relaxed, now allowed"
    elif i >= 6:
        extra = "   ← bias has learned the routine down"
    print(f"   run {i}: [{tag}] score={d.final_score:5.1f}  (L={d.likelihood:.2f} bias={d.bias:.2f}){extra}")

s.warm("ci-runner", "read_file", {"path": "src/app/server.py"}, 30)
s.warm("support-copilot", "read_file", {"path": "docs/handbook.md"}, 30)
s.warm("support-copilot", "read_file", {"path": "docs/faq.md"}, 20)

note("09:30 — established agents doing their normal work → allowed")
s.call("ci-runner", "read_file", {"path": "src/app/server.py"}, at="09:30",
       why="build agent reads its own source — proven routine")
s.call("support-copilot", "read_file", {"path": "docs/faq.md"}, at="09:44",
       why="support bot reads a public doc it has read many times")

# ── Part 2: the support bot is prompt-injected and drifts out of scope ──
note("11:20 — a poisoned support ticket injected instructions into support-copilot")
s.call("support-copilot", "list_directory", {"path": "sensitive/"}, at="11:20",
       why="enumerating the sensitive tree — out of scope, never done before")
s.call("support-copilot", "read_file", {"path": "sensitive/financials/payroll_2026_03.csv"}, at="11:21",
       why="reaching for payroll — out-of-scope on a high-ceiling cell → blocked")
s.call("support-copilot", "read_file", {"path": "sensitive/security/id_rsa"}, at="11:22",
       why="now the SSH private key — out-of-scope, first-ever, critical → blocked hard")

note("11:23 — the injection tries to stage the key to a world-readable location")
s.call("support-copilot", "move_file",
       {"source": "sensitive/security/id_rsa", "destination": "docs/public/leaked_key.txt"}, at="11:23",
       why="sensitive→public flow: the exposure factor forces a hard block regardless of ceiling")

# ── Part 3: crown-jewel cells stay protected even from an in-scope agent ──
note("Even an agent SCOPED to security can't autonomously read a live secret:")
s.register("secops-bot", "Security operations assistant.", ops={"read", "list"},
           assets={"sensitive/security/id_rsa", "sensitive/security/vault_token",
                   "sensitive/security/"})
s.warm("secops-bot", "list_directory", {"path": "sensitive/security/"}, 30)
s.call("secops-bot", "read_file", {"path": "sensitive/security/vault_token"}, at="14:05",
       why="in-scope and familiar with the directory, but reading a live vault token is")
print("          ↳ critical → still blocked; a human must approve. The ceiling is the backstop.")

print("\n" + "═" * 74)
print("  Routine work learned its way to ALLOW; the injected bot was blocked the")
print("  moment it left its lane; the crown jewels stay blocked for everyone.")
print("═" * 74)
