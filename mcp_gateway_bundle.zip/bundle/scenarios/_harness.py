"""
Shared harness for the realistic scenario scripts in this folder.

Each scenario file (filesystem_session.py, slack_session.py, …) builds a real-ish
static artifact for one MCP server, registers the agents that call it with their
declared purpose, then replays a sequence of calls that reads like real traffic —
a normal working period that drifts into an incident — and prints the gateway's
decision for each.

Run any scenario from the repo root:

    python scenarios/filesystem_session.py
    python scenarios/slack_session.py
    python scenarios/github_session.py
    python scenarios/payment_session.py
"""

from __future__ import annotations

import os
import sys

# make `mcp_security` importable when a scenario is run directly
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mcp_security.gateway import GatewayConfig, DynamicScorer          # noqa: E402
from mcp_security.gateway.artifact import StaticArtifact               # noqa: E402
from mcp_security.gateway.state import make_store                      # noqa: E402
from mcp_security.gateway.state.base import AppContext                 # noqa: E402


_ACTION_MARK = {"allow": "  ok ", "degrade": " warn", "drop": " BLOCK"}


class Session:
    """One MCP server + its scorer + its registered agents, with a replay helper."""

    def __init__(self, table: dict):
        self.artifact = StaticArtifact.from_table(table, version=table.get("server", "inline"))
        self.config = GatewayConfig(state_backend="memory")
        self.store = make_store(self.config)
        self.scorer = DynamicScorer(self.artifact, self.config, store=self.store)

    def register(self, app_id: str, purpose: str, ops: set[str], assets: set[str]) -> None:
        self.store.put_app_context(AppContext(
            app_id=app_id, expected_ops=ops, expected_assets=assets, purpose=purpose))

    def call(self, actor: str, tool: str, args: dict, *, at: str = "", why: str = "") -> None:
        d = self.scorer.score(actor, tool, args)
        mark = _ACTION_MARK.get(d.action.value, d.action.value)
        stamp = f"{at:>5}  " if at else ""
        # a compact, log-like line: time  DECISION  actor  tool(key-arg)
        keyarg = _summarise_args(args)
        print(f"{stamp}[{mark}] {actor:<16} {tool}({keyarg})")
        if why:
            print(f"          ↳ {why}")
        print(f"          ↳ score={d.final_score:6.1f} [{d.static_band or '-'}]  "
              f"ceiling={d.static_ceiling:g} × L={d.likelihood:.2f} × bias={d.bias:.2f}")

    def warm(self, actor: str, tool: str, args: dict, times: int) -> None:
        """Replay a benign call `times` times to build a baseline (no printing)."""
        for _ in range(times):
            self.scorer.score(actor, tool, args)


def _summarise_args(args: dict) -> str:
    for k in ("path", "source", "repo", "channel", "account", "payee", "query", "paths"):
        if k in args:
            v = args[k]
            if isinstance(v, list):
                return f"{k}=[{len(v)} items]"
            s = str(v)
            return f"{k}={s if len(s) <= 44 else s[:41] + '...'}"
    return ", ".join(list(args)[:2])


def header(title: str, subtitle: str = "") -> None:
    print("\n" + "═" * 74)
    print(f"  {title}")
    if subtitle:
        print(f"  {subtitle}")
    print("═" * 74)


def note(text: str) -> None:
    print(f"\n— {text}")
