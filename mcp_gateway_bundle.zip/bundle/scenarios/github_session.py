"""
GitHub MCP — an engineering org, one working session.

Cast:
  • pr-bot        — opens/updates PRs and reads code in app repos
  • ci-deployer   — reads repos, merges approved PRs
  • dependabot    — reads manifests, opens dependency PRs
  • contractor    — external contractor agent, scoped to one docs repo

Normal development traffic, then the contractor agent (compromised) tries to
read the infra repo, make it public, and delete a production repo. Everything
printed is exactly what the gateway returns.
"""

from _harness import Session, header, note

TABLE = {
    "server": "github:acme",
    "server_kind": "github",
    "score_max": 125,
    "asset_ids": ["acme/", "acme/webapp", "acme/api", "acme/infra", "acme/docs"],
    "cells": {
        "acme/":       {"read_file": 12, "create_pr": 16, "merge_pr": 48, "set_visibility": 80, "delete_repo": 100},
        "acme/webapp": {"read_file": 12, "create_pr": 16, "merge_pr": 48, "set_visibility": 80, "delete_repo": 100},
        "acme/api":    {"read_file": 15, "create_pr": 20, "merge_pr": 60, "set_visibility": 90, "delete_repo": 110},
        "acme/infra":  {"read_file": 20, "create_pr": 30, "merge_pr": 80, "set_visibility": 100, "delete_repo": 125},
        "acme/docs":   {"read_file": 4,  "create_pr": 8,  "merge_pr": 16, "set_visibility": 20, "delete_repo": 30},
    },
    "bands": {
        "acme/webapp": {"read_file": "low", "create_pr": "low", "merge_pr": "high", "set_visibility": "critical", "delete_repo": "critical"},
        "acme/api":    {"read_file": "low", "merge_pr": "high", "set_visibility": "critical", "delete_repo": "critical"},
        "acme/infra":  {"read_file": "medium", "merge_pr": "critical", "set_visibility": "critical", "delete_repo": "critical"},
        "acme/docs":   {"read_file": "low", "create_pr": "low", "merge_pr": "low"},
    },
    "tool_input_ranking": {
        "read_file":      {"inputs": [{"name": "repo", "type": "string", "risk": 4},
                                      {"name": "path", "type": "string", "risk": 2}]},
        "merge_pr":       {"inputs": [{"name": "repo", "type": "string", "risk": 5}]},
        "set_visibility": {"inputs": [{"name": "repo", "type": "string", "risk": 5},
                                      {"name": "visibility", "type": "string", "risk": 5}]},
        "delete_repo":    {"inputs": [{"name": "repo", "type": "string", "risk": 5}]},
    },
    "tool_impact_detail": {
        "read_file": {"primary_op": "read"}, "create_pr": {"primary_op": "write"},
        "merge_pr": {"primary_op": "merge"}, "set_visibility": {"primary_op": "admin"},
        "delete_repo": {"primary_op": "admin"},
    },
}

s = Session(TABLE)
s.register("pr-bot", "Opens and updates pull requests; reads application code.",
           ops={"read", "write"}, assets={"acme/webapp", "acme/api"})
s.register("ci-deployer", "Reads repos and merges approved PRs.",
           ops={"read", "merge"}, assets={"acme/webapp", "acme/api", "acme/infra"})
s.register("dependabot", "Reads manifests and opens dependency PRs.",
           ops={"read", "write"}, assets={"acme/webapp", "acme/api"})
s.register("contractor", "External contractor agent, scoped to the docs repo.",
           ops={"read", "write"}, assets={"acme/docs"})

s.warm("pr-bot", "read_file", {"repo": "acme/webapp", "path": "src/index.ts"}, 30)
s.warm("dependabot", "read_file", {"repo": "acme/api", "path": "package.json"}, 30)
s.warm("contractor", "read_file", {"repo": "acme/docs", "path": "guide.md"}, 30)

header("GitHub MCP · github:acme", "Normal development, then a compromised contractor targets infra")

note("routine development traffic")
s.call("pr-bot", "read_file", {"repo": "acme/webapp", "path": "src/index.ts"}, at="10:01",
       why="PR bot reading app code — proven routine")
s.call("pr-bot", "create_pr", {"repo": "acme/webapp", "title": "fix: null check"}, at="10:03",
       why="opening a PR on the webapp — in-scope; first PR so slightly elevated")
s.call("contractor", "read_file", {"repo": "acme/docs", "path": "guide.md"}, at="10:20",
       why="contractor reading the docs repo it's scoped to — routine")

note("15:10 — the contractor agent is compromised and reaches beyond the docs repo")
s.call("contractor", "read_file", {"repo": "acme/infra", "path": "terraform/main.tf"}, at="15:10",
       why="reading infra config — out of scope → flagged (degraded) for review")
s.call("contractor", "set_visibility", {"repo": "acme/infra", "visibility": "public"}, at="15:11",
       why="making the private infra repo PUBLIC — exposure strong + critical ceiling → blocked")
s.call("contractor", "delete_repo", {"repo": "acme/api"}, at="15:12",
       why="attempting to delete a production repo — out-of-scope, critical → blocked hard")

note("15:30 — a high-value in-scope action still needs human sign-off")
s.call("ci-deployer", "merge_pr", {"repo": "acme/webapp", "pr": 412}, at="15:30",
       why="in-scope, but merging to a high-ceiling repo autonomously is blocked — needs human sign-off")

print("\n" + "═" * 74)
print("  Dev traffic flows; the compromised contractor is blocked reaching infra,")
print("  making a repo public, and deleting production.")
print("═" * 74)
