"""
Payment MCP — a merchant payments backend, one working session.

Cast:
  • checkout-svc   — reads balances, creates charges for orders
  • refund-bot     — issues refunds against known customer transactions
  • reconcile-svc  — reads transactions and balances for nightly reconciliation
  • ops-console    — human-operated console agent (broad read)

Normal payment operations, then refund-bot (compromised) tries to send a large
payment to an unknown external payee. The protected asset for send_payment is
the merchant balance, which is implicit (not in the args) — the gateway resolves
it from the scan. Everything printed is exactly what the gateway returns.
"""

from _harness import Session, header, note

TABLE = {
    "server": "payment:merchant",
    "server_kind": "payment",
    "score_max": 125,
    "asset_ids": ["merchant_balance", "customer_txn", "customer_card", "payout_account"],
    "cells": {
        "merchant_balance": {"get_balance": 5, "create_charge": 40, "send_payment": 100},
        "customer_txn":     {"get_transaction": 6, "issue_refund": 20},
        "customer_card":    {"get_transaction": 10, "issue_refund": 24, "send_payment": 110},
        "payout_account":   {"get_balance": 8, "send_payment": 125},
    },
    "bands": {
        "merchant_balance": {"get_balance": "low", "create_charge": "high", "send_payment": "critical"},
        "customer_txn":     {"get_transaction": "low", "issue_refund": "medium"},
        "customer_card":    {"get_transaction": "low", "issue_refund": "medium", "send_payment": "critical"},
        "payout_account":   {"get_balance": "low", "send_payment": "critical"},
    },
    "inferred_profile": {
        # send_payment debits the merchant balance; the payee arg is the SINK,
        # not the asset. The gateway reads the protected asset from here.
        "implicit_assets": {"send_payment": "merchant_balance",
                            "create_charge": "merchant_balance"},
    },
    "tool_input_ranking": {
        "get_balance":     {"inputs": [{"name": "account", "type": "string", "risk": 2}]},
        "get_transaction": {"inputs": [{"name": "txn", "type": "string", "risk": 2}]},
        "issue_refund":    {"inputs": [{"name": "txn", "type": "string", "risk": 3},
                                       {"name": "payee", "type": "string", "risk": 4}]},
        "send_payment":    {"inputs": [{"name": "payee", "type": "string", "risk": 5},
                                       {"name": "amount", "type": "number", "risk": 4}]},
    },
    "tool_impact_detail": {
        "get_balance": {"primary_op": "read"}, "get_transaction": {"primary_op": "read"},
        "create_charge": {"primary_op": "charge"}, "issue_refund": {"primary_op": "refund"},
        "send_payment": {"primary_op": "payout"},
    },
}

s = Session(TABLE)
s.register("checkout-svc", "Reads balances and creates charges for customer orders.",
           ops={"read", "charge"}, assets={"merchant_balance"})
s.register("refund-bot", "Issues refunds against known customer transactions.",
           ops={"read", "refund"}, assets={"customer_txn", "customer_card"})
s.register("reconcile-svc", "Nightly reconciliation; reads transactions and balances.",
           ops={"read"}, assets={"merchant_balance", "customer_txn"})

s.warm("checkout-svc", "get_balance", {"account": "merchant_balance"}, 30)
s.warm("refund-bot", "get_transaction", {"txn": "txn_1001"}, 30)
s.warm("refund-bot", "issue_refund", {"txn": "txn_seed", "payee": "customer_card"}, 12)
s.warm("reconcile-svc", "get_transaction", {"txn": "txn_1001"}, 30)

header("Payment MCP · payment:merchant", "Normal payments, then a compromised refund bot tries a payout")

note("routine payment operations")
s.call("checkout-svc", "get_balance", {"account": "merchant_balance"}, at="08:00",
       why="checkout reading the merchant balance — proven routine")
s.call("refund-bot", "issue_refund", {"txn": "txn_2087", "payee": "customer_card"}, at="09:15",
       why="refund to the original customer card — in-scope and now routine → allowed")
s.call("reconcile-svc", "get_transaction", {"txn": "txn_2087"}, at="23:30",
       why="nightly reconciliation reading a transaction — routine")

note("11:00 next day — refund-bot is compromised and attempts a payout")
s.call("refund-bot", "send_payment", {"payee": "external-wallet-9df2", "amount": 48000}, at="11:00",
       why="send_payment resolves to the implicit merchant_balance (critical); payee is unknown/external")
print("          ↳ out-of-scope op + unknown external payee + critical asset → blocked hard")

note("11:02 — it also tries to drain the payout account")
s.call("refund-bot", "send_payment", {"payee": "external-wallet-9df2", "amount": 90000, "account": "payout_account"}, at="11:02",
       why="payout_account send_payment is the highest cell in the matrix → blocked")

note("11:20 — legitimate refund traffic continues")
s.call("refund-bot", "issue_refund", {"txn": "txn_2090", "payee": "customer_card"}, at="11:20",
       why="a normal customer refund — in-scope; the compromise didn't taint this cell")

print("\n" + "═" * 74)
print("  Reads and refunds flow; the payout to an unknown external payee is blocked,")
print("  with the protected asset (merchant balance) resolved implicitly from the scan.")
print("═" * 74)
