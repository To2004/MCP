"""
Runner for the inference-based pipeline.

Default uses two MOCK clients so the whole flow -- domain inference, proposing,
judging, disagreement routing -- runs with no credentials. Swap in real clients
via build_client() (see llm/client.py) for production.

Usage:
    python run_pipeline.py \
        --tools examples/payment_tools.json \
        --assets examples/payment_assets.json \
        --apps examples/payment_apps.json \
        --out out/payment_static_table.json
"""

from __future__ import annotations
import argparse, json, os, sys
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from scorer.pipeline import InferenceScoringPipeline
from llm.client import build_client


# --- Mock clients ------------------------------------------------------------

_DESTRUCTIVE = ("delete", "drop", "truncate", "purge", "overwrite", "exec",
                "run", "transfer", "payout", "send_payment", "revoke", "wipe")
_WRITE = ("write", "edit", "update", "create", "move", "rename", "insert",
          "refund", "authorize")


def _first_json(text: str) -> dict:
    i = text.find("{")
    depth = 0
    for j in range(i, len(text)):
        if text[j] == "{": depth += 1
        elif text[j] == "}":
            depth -= 1
            if depth == 0:
                try: return json.loads(text[i:j+1])
                except Exception: return {}
    return {}


class MockProposer:
    name = "mock-proposer"
    def complete(self, system, user):
        if "security analyst bootstrapping" in system:
            return json.dumps({
                "mcp_kind": "inferred system (mock)",
                "asset_meaning": "a category of protected object",
                "blast_radius_meaning": "how broadly/irreversibly a tool acts on it",
                "dangerous_classes": ["holds secrets", "moves money", "executable"],
                "irreversible_actions": ["delete", "drop", "transfer", "exec"],
                "worked_example": "destructive tool on a secret-holding asset = critical",
                "confidence": 0.9, "needs_human_review": False})
        if "TOOL IMPACT" in system:
            t = _first_json(user); n = t.get("name", "x").lower()
            imp = 1
            if any(k in n for k in _WRITE): imp = 2
            if any(k in n for k in _DESTRUCTIVE): imp = 3
            return json.dumps({"tool_name": t.get("name"), "tool_impact": imp,
                "irreversible": imp == 3, "worst_case": "mock", "trigger_capability": n,
                "confidence": 0.9, "reasoning": "mock verb heuristic"})
        if "ASSET SENSITIVITY" in system:
            a = _first_json(user); pr = str(a.get("org_priority", "3")).lower()
            pmap = {"critical": 5, "high": 4, "medium": 3, "low": 2, "negligible": 1}
            return json.dumps({"asset_id": a.get("asset_id"),
                "sensitivity": pmap.get(pr, 3), "drivers": ["mock"],
                "confidence": 0.9, "reasoning": "mock"})
        if "Build the behavioral baseline" in system:
            a = _first_json(user)
            return json.dumps({"app_id": a.get("app_id"), "expected_tools": ["read"],
                "expected_flows": [{"pattern": "read internal", "normal_sensitivity_max": 3}],
                "anomalous_patterns": ["sensitive -> public"], "confidence": 0.9,
                "reasoning": "mock"})
        if "Assign BLAST RADIUS" in system:
            blk = _first_json(user)
            n = blk.get("name", "x").lower()
            aid = _first_json(user[user.find("Asset class"):]).get("asset_id", "x") if "Asset class" in user else "x"
            br = 1
            if any(k in n for k in _WRITE): br = 2
            if any(k in n for k in _DESTRUCTIVE): br = 4
            return json.dumps({"tool_name": blk.get("name"), "asset_id": aid,
                "blast_radius": br, "rationale": "mock", "confidence": 0.9})
        return "{}"


class MockJudge:
    """Agrees, but deliberately escalates one risky case to show disagreement."""
    name = "mock-judge"
    def complete(self, system, user):
        # field name is in the user prompt: "Decision under review: <field> for ..."
        line = user.splitlines()[0]
        field = line.split("Decision under review:")[1].split("for")[0].strip()
        proposed = _first_json(user[user.find("First model's answer"):])
        val = proposed.get(field)
        # Escalate: if proposer said blast_radius 2 on a money/secret asset, judge says 4
        if field == "blast_radius" and val == 2 and ("payout" in user or "credentials" in user or "card" in user):
            return json.dumps({"agree": False, "judged_value": 4,
                "reasoning": "mock judge: dangerous asset, escalate", "confidence": 0.9})
        return json.dumps({"agree": True, "judged_value": val,
            "reasoning": "mock judge agrees", "confidence": 0.9})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tools", required=True)
    ap.add_argument("--assets", required=True)
    ap.add_argument("--apps", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--bands", default='{"low":6,"medium":18,"high":36}')
    ap.add_argument("--real", action="store_true")
    ap.add_argument("--proposer", default='{"provider":"anthropic","model":"claude-opus-4-8","temperature":0.0}')
    ap.add_argument("--judge", default='{"provider":"anthropic","model":"claude-sonnet-4-6","temperature":0.3}')
    args = ap.parse_args()

    if args.real:
        proposer = build_client(json.loads(args.proposer))
        judge = build_client(json.loads(args.judge))
    else:
        proposer, judge = MockProposer(), MockJudge()

    tools = json.load(open(args.tools))
    assets = json.load(open(args.assets))
    apps = json.load(open(args.apps))

    pipe = InferenceScoringPipeline(proposer, judge, bands=json.loads(args.bands))
    profile = pipe.infer_domain(tools, assets)
    print(f"inferred domain: {profile.mcp_kind} (conf {profile.confidence})")

    for t in tools: pipe.score_tool_impact(t)
    for a in assets: pipe.score_asset(a)
    for t in tools:
        for a in assets: pipe.score_blast(t, a)
    for app in apps: pipe.score_baseline(app)

    version = f"static-{date.today().isoformat()}"
    table = pipe.build_table(version)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    json.dump(table, open(args.out, "w"), indent=2)
    json.dump(pipe.review_queue, open(args.out.replace(".json", ".review.json"), "w"), indent=2)

    n_cells = sum(len(v) for v in table["cells"].values())
    print(f"table -> {args.out}")
    print(f"  cells={n_cells}  review_flags={len(pipe.review_queue)}")
    for item in pipe.review_queue:
        print(f"  REVIEW [{item['kind']}] {item['key']}: {item.get('reasons')}")


if __name__ == "__main__":
    main()
