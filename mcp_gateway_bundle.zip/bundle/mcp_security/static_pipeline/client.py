"""
Provider-agnostic LLM interface.

The pipeline depends ONLY on the `LLMClient` protocol below -- one method,
`complete(system, user) -> str`. Concrete adapters wrap whatever vendor you use.
Swap providers by constructing a different adapter; no pipeline code changes.

Two distinct roles are used by the two-model cross-check:
  - a PROPOSER client (does the scoring)
  - a JUDGE client (independently verifies)
They can be different vendors, different models, or the same model at different
temperatures -- whatever gives you independent signal.

The adapters here are thin stubs. Fill in the marked TODO with your real call.
Keeping them stubs means this file has no hard SDK dependency; install only the
SDK for the provider you actually use.
"""

from __future__ import annotations
from typing import Protocol, Optional
import os


class LLMClient(Protocol):
    """The only contract the pipeline knows about."""
    name: str

    def complete(self, system: str, user: str) -> str:
        """Return the model's raw text response."""
        ...


# --- Adapters ----------------------------------------------------------------

class AnthropicClient:
    def __init__(self, model: str = "claude-opus-4-8", temperature: float = 0.0,
                 max_tokens: int = 1024, name: Optional[str] = None):
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.name = name or f"anthropic:{model}"

    def complete(self, system: str, user: str) -> str:
        import anthropic  # imported lazily so the SDK is optional
        client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY
        resp = client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return "".join(b.text for b in resp.content if b.type == "text")


class OpenAIClient:
    def __init__(self, model: str = "gpt-4.1", temperature: float = 0.0,
                 max_tokens: int = 1024, name: Optional[str] = None):
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.name = name or f"openai:{model}"

    def complete(self, system: str, user: str) -> str:
        from openai import OpenAI  # lazy import
        client = OpenAI()  # reads OPENAI_API_KEY
        resp = client.chat.completions.create(
            model=self.model,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        return resp.choices[0].message.content or ""


class LocalEndpointClient:
    """
    For self-hosted / OpenAI-compatible endpoints (vLLM, Ollama, TGI, etc.).
    Anything exposing a /chat/completions style API.
    """
    def __init__(self, base_url: str, model: str, temperature: float = 0.0,
                 max_tokens: int = 1024, api_key_env: str = "LOCAL_LLM_KEY",
                 name: Optional[str] = None):
        self.base_url = base_url
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.api_key_env = api_key_env
        self.name = name or f"local:{model}"

    def complete(self, system: str, user: str) -> str:
        import requests  # lazy import
        r = requests.post(
            f"{self.base_url.rstrip('/')}/chat/completions",
            headers={"Authorization": f"Bearer {os.getenv(self.api_key_env, '')}"},
            json={
                "model": self.model,
                "temperature": self.temperature,
                "max_tokens": self.max_tokens,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
            },
            timeout=60,
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]


# --- Factory -----------------------------------------------------------------

def build_client(spec: dict) -> LLMClient:
    """
    spec example:
      {"provider": "anthropic", "model": "claude-opus-4-8", "temperature": 0.0}
      {"provider": "openai", "model": "gpt-4.1"}
      {"provider": "local", "base_url": "http://localhost:8000/v1", "model": "..."}
    """
    p = spec["provider"]
    kw = {k: v for k, v in spec.items() if k != "provider"}
    if p == "anthropic":
        return AnthropicClient(**kw)
    if p == "openai":
        return OpenAIClient(**kw)
    if p == "local":
        return LocalEndpointClient(**kw)
    raise ValueError(f"unknown provider: {p}")
