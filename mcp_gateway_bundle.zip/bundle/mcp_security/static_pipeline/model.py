"""
Data model for the inference-based pipeline.

Difference from the config-based version: there are NO override tables and NO
human-authored domain context. Domain knowledge is an inferred artifact
(`DomainProfile`) produced once from the registry scan, then reused.

Every scored value carries a `CrossCheck` showing the proposer's answer, the
judge's answer, and whether they agreed -- this is the only safety backstop.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import IntEnum
from typing import Optional, Any


class ToolImpact(IntEnum):
    READ_ONLY = 1
    RECOVERABLE = 2
    DESTRUCTIVE = 3


# --- Inputs (from the scanner) ----------------------------------------------

@dataclass
class ToolDef:
    name: str
    description: str = ""
    input_schema: dict = field(default_factory=dict)
    annotations: dict = field(default_factory=dict)


@dataclass
class AssetClass:
    asset_id: str
    descriptor: str = ""
    org_priority: Optional[str] = None
    attributes: dict = field(default_factory=dict)


@dataclass
class AppProfile:
    app_id: str
    purpose: str = ""
    declared_operations: str = ""
    owner_team: str = ""


# --- Inferred domain knowledge (produced once, reused everywhere) ------------

@dataclass
class DomainProfile:
    """
    What the LLM figured out about this MCP from its registry alone. This
    replaces the hand-written YAML domain_context of the config-based design.
    """
    mcp_kind: str                       # e.g. "filesystem", "sql database", "payment processor"
    asset_meaning: str                  # what an asset class IS in this domain
    blast_radius_meaning: str           # what "reach" means here
    dangerous_classes: list             # asset-class traits that should escalate
    irreversible_actions: list          # tool traits that imply tier 3
    worked_example: str                 # a concrete (tool,asset)->reasoning example
    confidence: float
    needs_human_review: bool
    raw: dict = field(default_factory=dict)

    def as_context(self) -> str:
        """Render into the injectable block every classifier prompt receives."""
        return (
            f"MCP KIND: {self.mcp_kind}\n"
            f"WHAT AN ASSET CLASS MEANS HERE: {self.asset_meaning}\n"
            f"WHAT BLAST RADIUS / REACH MEANS HERE: {self.blast_radius_meaning}\n"
            f"ASSET CLASSES THAT SHOULD ESCALATE: {', '.join(self.dangerous_classes)}\n"
            f"ACTIONS THAT ARE IRREVERSIBLE (tier 3): {', '.join(self.irreversible_actions)}\n"
            f"WORKED EXAMPLE: {self.worked_example}"
        )


# --- Cross-check records -----------------------------------------------------

@dataclass
class CrossCheck:
    """Proposer vs judge on a single scalar value."""
    field_name: str
    proposed: Any
    judged: Any
    agreed: bool
    proposer: str
    judge: str
    judge_reasoning: str = ""


@dataclass
class ScoredRecord:
    """A classifier output plus its cross-check trail and final accepted value."""
    kind: str                    # tool_impact | asset_sensitivity | blast_radius | baseline
    key: str
    accepted: dict               # the final values used by the engine
    proposer_raw: dict
    judge_raw: dict
    crosschecks: list            # list[CrossCheck]
    needs_human_review: bool
    review_reasons: list = field(default_factory=list)


# --- Band mapping (display only) --------------------------------------------

@dataclass
class BandThresholds:
    low: int = 4
    medium: int = 12
    high: int = 24

    def band(self, score: Optional[int]) -> str:
        if score is None:
            return "N/A"
        if score <= self.low:
            return "Low"
        if score <= self.medium:
            return "Medium"
        if score <= self.high:
            return "High"
        return "Critical"


def to_dict(obj) -> dict:
    return asdict(obj)
