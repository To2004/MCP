"""
Inference-based static scoring pipeline.

Flow:
  1. infer_domain(registry)            -> DomainProfile (once, reused)
  2. per item: proposer scores         -> judge independently verifies
       agree    -> accept proposer value
       disagree -> route to review queue, carry BOTH values
  3. deterministic assembly            -> static score table (pure math)

No config, no overrides. The judge is the safety backstop. The scoring math
never touches an LLM.
"""

from __future__ import annotations
import json
from dataclasses import asdict
from typing import Optional

try:
    import jsonschema
except ImportError:
    jsonschema = None

from llm.client import LLMClient
from prompts import builders
from schemas.classifier_schemas import SCHEMAS
from .model import (DomainProfile, BandThresholds, CrossCheck, ScoredRecord)


class PipelineError(Exception):
    pass


def _parse_json(raw: str) -> dict:
    s = raw.strip()
    if s.startswith("```"):
        inner = s[3:]
        s = inner.split("```", 1)[0]
        s = s.lstrip("json").strip()
    try:
        return json.loads(s)
    except json.JSONDecodeError as e:
        raise PipelineError(f"non-JSON LLM output: {e}\nraw: {raw[:400]}")


def _validate(obj: dict, key: str) -> None:
    if jsonschema is not None:
        jsonschema.validate(obj, SCHEMAS[key])


class InferenceScoringPipeline:
    def __init__(self, proposer: LLMClient, judge: LLMClient,
                 bands: Optional[dict] = None, judge_confidence_floor: float = 0.6):
        self.proposer = proposer
        self.judge = judge
        self.bands = BandThresholds(**(bands or {}))
        self.judge_floor = judge_confidence_floor
        self.profile: Optional[DomainProfile] = None
        self.review_queue: list[dict] = []
        self.records: list[ScoredRecord] = []

    # --- step 1: domain inference (once) -------------------------------------

    def infer_domain(self, tools: list, assets: list) -> DomainProfile:
        system, user = builders.build_domain_inference_prompt(tools, assets)
        rec = _parse_json(self.proposer.complete(system, user))
        _validate(rec, "domain_profile")
        self.profile = DomainProfile(
            mcp_kind=rec["mcp_kind"], asset_meaning=rec["asset_meaning"],
            blast_radius_meaning=rec["blast_radius_meaning"],
            dangerous_classes=rec["dangerous_classes"],
            irreversible_actions=rec["irreversible_actions"],
            worked_example=rec["worked_example"], confidence=rec["confidence"],
            needs_human_review=rec["needs_human_review"], raw=rec,
        )
        if self.profile.needs_human_review or self.profile.confidence < 0.7:
            self.review_queue.append({
                "kind": "domain_profile", "key": self.profile.mcp_kind,
                "record": rec, "reasons": ["low-confidence domain inference"],
            })
        return self.profile

    def _ctx(self) -> str:
        if self.profile is None:
            raise PipelineError("call infer_domain() before scoring")
        return self.profile.as_context()

    # --- the two-model cross-check core --------------------------------------

    def _crosscheck(self, kind: str, key: str, field_name: str,
                    item: dict, proposed: dict, schema_key: str) -> ScoredRecord:
        _validate(proposed, schema_key)
        js, ju = builders.build_judge_prompt(field_name, key, item, proposed, self._ctx())
        verdict = _parse_json(self.judge.complete(js, ju))
        _validate(verdict, "judge_verdict")

        proposed_val = proposed[field_name]
        judged_val = verdict["judged_value"]
        agreed = bool(verdict["agree"]) and proposed_val == judged_val

        cc = CrossCheck(
            field_name=field_name, proposed=proposed_val, judged=judged_val,
            agreed=agreed, proposer=self.proposer.name, judge=self.judge.name,
            judge_reasoning=verdict.get("reasoning", ""),
        )

        reasons = []
        needs_review = False
        if not agreed:
            needs_review = True
            reasons.append(
                f"proposer={proposed_val} vs judge={judged_val} on {field_name}")
        if float(proposed.get("confidence", 1.0)) < self.judge_floor:
            needs_review = True
            reasons.append("low proposer confidence")
        if float(verdict.get("confidence", 1.0)) < self.judge_floor:
            needs_review = True
            reasons.append("low judge confidence")

        # Conservative accept policy: when they disagree, take the HIGHER
        # (more cautious) value so the held score never under-protects while
        # awaiting human sign-off.
        accepted = dict(proposed)
        if not agreed and isinstance(proposed_val, int) and isinstance(judged_val, int):
            accepted[field_name] = max(proposed_val, judged_val)

        rec = ScoredRecord(
            kind=kind, key=key, accepted=accepted, proposer_raw=proposed,
            judge_raw=verdict, crosschecks=[asdict(cc)],
            needs_human_review=needs_review, review_reasons=reasons,
        )
        self.records.append(rec)
        if needs_review:
            self.review_queue.append({
                "kind": kind, "key": key, "record": asdict(rec), "reasons": reasons})
        return rec

    # --- proposers + crosscheck wrappers -------------------------------------

    def score_tool_impact(self, tool: dict) -> ScoredRecord:
        s, u = builders.build_tool_impact_prompt(tool, self._ctx())
        proposed = _parse_json(self.proposer.complete(s, u))
        return self._crosscheck("tool_impact", tool["name"], "tool_impact",
                                tool, proposed, "tool_impact")

    def score_asset(self, asset: dict) -> ScoredRecord:
        s, u = builders.build_asset_prompt(asset, self._ctx())
        proposed = _parse_json(self.proposer.complete(s, u))
        return self._crosscheck("asset_sensitivity", asset["asset_id"],
                                "sensitivity", asset, proposed, "asset_sensitivity")

    def score_blast(self, tool: dict, asset: dict) -> ScoredRecord:
        s, u = builders.build_blast_prompt(tool, asset, self._ctx())
        proposed = _parse_json(self.proposer.complete(s, u))
        key = f"{tool['name']}|{asset['asset_id']}"
        item = {"tool": tool, "asset": asset}
        return self._crosscheck("blast_radius", key, "blast_radius",
                                item, proposed, "blast_radius")

    def score_baseline(self, app: dict) -> ScoredRecord:
        s, u = builders.build_baseline_prompt(app, self._ctx())
        proposed = _parse_json(self.proposer.complete(s, u))
        _validate(proposed, "baseline")
        rec = ScoredRecord(
            kind="baseline", key=app["app_id"], accepted=proposed,
            proposer_raw=proposed, judge_raw={}, crosschecks=[],
            needs_human_review=proposed.get("confidence", 1.0) < self.judge_floor,
            review_reasons=["low confidence"] if proposed.get("confidence", 1.0) < self.judge_floor else [],
        )
        self.records.append(rec)
        if rec.needs_human_review:
            self.review_queue.append({"kind": "baseline", "key": app["app_id"],
                                      "record": asdict(rec), "reasons": rec.review_reasons})
        return rec

    # --- deterministic assembly ----------------------------------------------

    def build_table(self, version: str) -> dict:
        tool_impact, sensitivity, blast, baselines = {}, {}, {}, {}
        for r in self.records:
            if r.kind == "tool_impact":
                tool_impact[r.key] = r.accepted["tool_impact"]
            elif r.kind == "asset_sensitivity":
                sensitivity[r.key] = r.accepted["sensitivity"]
            elif r.kind == "blast_radius":
                blast[r.key] = r.accepted["blast_radius"]
            elif r.kind == "baseline":
                baselines[r.key] = r.accepted

        cells = {}
        for bk, br in blast.items():
            tname, aid = bk.split("|", 1)
            if tname not in tool_impact or aid not in sensitivity:
                continue
            if br == 0:
                cells.setdefault(aid, {})[tname] = None
                continue
            score = round(sensitivity[aid] * br * 1.0 * tool_impact[tname])
            cells.setdefault(aid, {})[tname] = score

        return {
            "version": version,
            "mcp_kind": self.profile.mcp_kind if self.profile else "unknown",
            "inferred_profile": self.profile.raw if self.profile else {},
            "formula": "asset_sensitivity * blast_radius * likelihood(1.0) * tool_impact",
            "band_thresholds": asdict(self.bands),
            "tool_impact": tool_impact,
            "asset_sensitivity": sensitivity,
            "blast_radius": blast,
            "cells": cells,
            "baselines": baselines,
            "crosscheck_summary": {
                "total_records": len(self.records),
                "flagged_for_review": len(self.review_queue),
            },
        }

    def band_of(self, score: Optional[int]) -> str:
        return self.bands.band(score)
