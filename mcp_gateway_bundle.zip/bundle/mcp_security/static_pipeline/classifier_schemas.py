"""
JSON Schemas for every LLM output in the inference-based pipeline:
  - domain_profile : the one-time domain inference pass
  - tool_impact / asset_sensitivity / blast_radius / baseline : proposers
  - judge_verdict : the cross-check verifier's structured response
"""

DOMAIN_PROFILE_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["mcp_kind", "asset_meaning", "blast_radius_meaning",
                 "dangerous_classes", "irreversible_actions", "worked_example",
                 "confidence", "needs_human_review"],
    "properties": {
        "mcp_kind": {"type": "string"},
        "asset_meaning": {"type": "string"},
        "blast_radius_meaning": {"type": "string"},
        "dangerous_classes": {"type": "array", "items": {"type": "string"}},
        "irreversible_actions": {"type": "array", "items": {"type": "string"}},
        "worked_example": {"type": "string"},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        "needs_human_review": {"type": "boolean"},
    },
}

TOOL_IMPACT_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["tool_name", "tool_impact", "irreversible", "worst_case",
                 "trigger_capability", "confidence", "reasoning"],
    "properties": {
        "tool_name": {"type": "string"},
        "tool_impact": {"type": "integer", "enum": [1, 2, 3]},
        "irreversible": {"type": "boolean"},
        "worst_case": {"type": "string"},
        "trigger_capability": {"type": "string"},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        "reasoning": {"type": "string"},
    },
}

ASSET_SENSITIVITY_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["asset_id", "sensitivity", "drivers", "confidence", "reasoning"],
    "properties": {
        "asset_id": {"type": "string"},
        "sensitivity": {"type": "integer", "minimum": 1, "maximum": 5},
        "drivers": {"type": "array", "items": {"type": "string"}},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        "reasoning": {"type": "string"},
    },
}

BLAST_RADIUS_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["tool_name", "asset_id", "blast_radius", "rationale", "confidence"],
    "properties": {
        "tool_name": {"type": "string"},
        "asset_id": {"type": "string"},
        "blast_radius": {"type": "integer", "minimum": 0, "maximum": 4},
        "rationale": {"type": "string"},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
    },
}

BASELINE_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["app_id", "expected_tools", "expected_flows",
                 "anomalous_patterns", "confidence", "reasoning"],
    "properties": {
        "app_id": {"type": "string"},
        "expected_tools": {"type": "array", "items": {"type": "string"}},
        "expected_flows": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["pattern", "normal_sensitivity_max"],
                "properties": {
                    "pattern": {"type": "string"},
                    "normal_sensitivity_max": {"type": "integer", "minimum": 1, "maximum": 5},
                },
            },
        },
        "anomalous_patterns": {"type": "array", "items": {"type": "string"}},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        "reasoning": {"type": "string"},
    },
}

# The judge returns its own independent value for the same field, plus a verdict.
JUDGE_VERDICT_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["agree", "judged_value", "reasoning", "confidence"],
    "properties": {
        "agree": {"type": "boolean"},
        "judged_value": {},  # type depends on field; validated loosely
        "reasoning": {"type": "string"},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
    },
}

SCHEMAS = {
    "domain_profile": DOMAIN_PROFILE_SCHEMA,
    "tool_impact": TOOL_IMPACT_SCHEMA,
    "asset_sensitivity": ASSET_SENSITIVITY_SCHEMA,
    "blast_radius": BLAST_RADIUS_SCHEMA,
    "baseline": BASELINE_SCHEMA,
    "judge_verdict": JUDGE_VERDICT_SCHEMA,
}
