"""The behavioural-baseline store interface.

This is the stateful heart of the gateway and the part that MUST be swappable:
an in-memory dict for tests, Redis (or any shared KV) in production so the
baseline survives restarts and is shared across gateway workers. The scorer only
ever talks to this interface, never to a concrete backend.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class AppContext:
    """What an app is DECLARED to do, compiled offline from its high-level context
    (see mcp_security.app_context.compiler). The anomaly factor checks membership
    against these sets at runtime."""

    app_id: str
    expected_ops: set[str] = field(default_factory=set)
    expected_assets: set[str] = field(default_factory=set)
    purpose: str = ""


class BaselineStore(ABC):
    """Per-app behavioural state: how often (app, tool, asset) has been seen, and
    each app's declared context. Implementations must be safe for concurrent
    callers (the memory impl uses a lock; Redis is atomic per op)."""

    # --- the behavioural baseline (mutated at runtime) -----------------------
    @abstractmethod
    def count(self, app_id: str, tool: str, asset: str) -> int:
        """Prior benign invocations of this (app, tool, asset)."""

    @abstractmethod
    def observe(self, app_id: str, tool: str, asset: str) -> None:
        """Record one benign invocation (called only for allowed/degraded calls)."""

    @abstractmethod
    def seen_tool(self, app_id: str, tool: str) -> bool:
        """Has this app ever successfully used this tool at all?"""

    # --- the declared context (written offline, read at runtime) -------------
    @abstractmethod
    def get_app_context(self, app_id: str) -> AppContext | None: ...

    @abstractmethod
    def put_app_context(self, ctx: AppContext) -> None: ...

    # optional lifecycle hooks
    def close(self) -> None:  # noqa: B027 - intentional no-op default
        pass
