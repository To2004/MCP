"""Baseline-store package. `make_store` selects a backend from config.

The __init__ was not among the uploaded sources; it is reconstructed to provide
the `make_store` factory the scorer imports (`from .state import make_store`).
"""
from .base import BaselineStore, AppContext
from .memory import MemoryBaselineStore

try:
    from .redis import RedisBaselineStore
except Exception:  # redis client may be absent in dev
    RedisBaselineStore = None  # type: ignore


def make_store(config) -> BaselineStore:
    backend = getattr(config, "state_backend", "memory")
    if backend == "redis":
        if RedisBaselineStore is None:
            raise RuntimeError("redis backend requested but RedisBaselineStore unavailable")
        return RedisBaselineStore(getattr(config, "redis_url", "redis://localhost:6379/0"))
    return MemoryBaselineStore()


__all__ = ["BaselineStore", "AppContext", "MemoryBaselineStore",
           "RedisBaselineStore", "make_store"]
