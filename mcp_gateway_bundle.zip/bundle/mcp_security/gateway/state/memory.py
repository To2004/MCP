"""In-memory baseline store — single process, thread-safe. For dev, tests, and
single-worker deployments. Not durable; use RedisBaselineStore in production."""

from __future__ import annotations

import threading

from .base import AppContext, BaselineStore


class MemoryBaselineStore(BaselineStore):
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._counts: dict[tuple[str, str, str], int] = {}
        self._tools: dict[str, set[str]] = {}
        self._ctx: dict[str, AppContext] = {}

    def count(self, app_id: str, tool: str, asset: str) -> int:
        with self._lock:
            return self._counts.get((app_id, tool, asset), 0)

    def observe(self, app_id: str, tool: str, asset: str) -> None:
        with self._lock:
            k = (app_id, tool, asset)
            self._counts[k] = self._counts.get(k, 0) + 1
            self._tools.setdefault(app_id, set()).add(tool)

    def seen_tool(self, app_id: str, tool: str) -> bool:
        with self._lock:
            return tool in self._tools.get(app_id, ())

    def get_app_context(self, app_id: str) -> AppContext | None:
        with self._lock:
            return self._ctx.get(app_id)

    def put_app_context(self, ctx: AppContext) -> None:
        with self._lock:
            self._ctx[ctx.app_id] = ctx
