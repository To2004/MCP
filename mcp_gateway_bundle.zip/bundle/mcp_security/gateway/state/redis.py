"""Redis-backed baseline store — durable, shared across gateway workers.

Uses atomic INCR for counts and a SET for the per-app tool history, so concurrent
gateway workers never race. App context is a JSON blob per app. Keys are
namespaced so one Redis can serve several gateways.

``redis`` is imported lazily: the module loads even where the package isn't
installed, so the gateway can default to the memory store in dev without pulling
the dependency. Construction raises a clear error if redis is genuinely needed
but absent.
"""

from __future__ import annotations

import json

from .base import AppContext, BaselineStore


class RedisBaselineStore(BaselineStore):
    def __init__(self, url: str, namespace: str = "mcpgw", ttl_seconds: int = 0) -> None:
        try:
            import redis  # noqa: PLC0415 - lazy so the dep is optional
        except ImportError as exc:  # pragma: no cover - environment-dependent
            raise RuntimeError(
                "RedisBaselineStore needs the 'redis' package: pip install redis"
            ) from exc
        self._r = redis.Redis.from_url(url, decode_responses=True)
        self._ns = namespace
        self._ttl = ttl_seconds

    # key helpers
    def _ck(self, app: str, tool: str, asset: str) -> str:
        return f"{self._ns}:cnt:{app}:{tool}:{asset}"

    def _tk(self, app: str) -> str:
        return f"{self._ns}:tools:{app}"

    def _xk(self, app: str) -> str:
        return f"{self._ns}:ctx:{app}"

    def count(self, app_id: str, tool: str, asset: str) -> int:
        v = self._r.get(self._ck(app_id, tool, asset))
        return int(v) if v else 0

    def observe(self, app_id: str, tool: str, asset: str) -> None:
        key = self._ck(app_id, tool, asset)
        pipe = self._r.pipeline()
        pipe.incr(key)
        if self._ttl:
            pipe.expire(key, self._ttl)
        pipe.sadd(self._tk(app_id), tool)
        pipe.execute()

    def seen_tool(self, app_id: str, tool: str) -> bool:
        return bool(self._r.sismember(self._tk(app_id), tool))

    def get_app_context(self, app_id: str) -> AppContext | None:
        blob = self._r.get(self._xk(app_id))
        if not blob:
            return None
        d = json.loads(blob)
        return AppContext(
            app_id=app_id,
            expected_ops=set(d.get("expected_ops", [])),
            expected_assets=set(d.get("expected_assets", [])),
            purpose=d.get("purpose", ""),
        )

    def put_app_context(self, ctx: AppContext) -> None:
        self._r.set(
            self._xk(ctx.app_id),
            json.dumps(
                {
                    "expected_ops": sorted(ctx.expected_ops),
                    "expected_assets": sorted(ctx.expected_assets),
                    "purpose": ctx.purpose,
                }
            ),
        )

    def close(self) -> None:
        self._r.close()
