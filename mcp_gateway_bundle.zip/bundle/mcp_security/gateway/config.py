"""Every gateway knob in one dataclass, loadable from a dict or env.

Kept separate from the scoring code so an operator tunes behaviour without
touching logic, and so a config can be versioned alongside a scan artifact.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class GatewayConfig:
    # === LIKELIHOOD FACTORS — one-sided, each >= 1.0 =========================
    # Every factor can only RAISE the score (it is an alarm, never a reward).
    # The single downward force is the learned `bias` below. Shared tier scheme
    # for all factors; values are placeholders pending calibration
    # (see NIST SP 800-30 / OWASP Risk Rating for the multiplicative structure).
    factor_normal: float = 1.0      # no signal on this axis
    factor_elevated: float = 1.3    # one clear signal
    factor_strong: float = 1.6      # unambiguous, or two signals
    likelihood_cap: float = 3.0     # a single call can't run away

    # --- access anomaly (out-of-declared-scope) ------------------------------
    # in-scope is NORMAL (1.0, absence of alarm) — never a reward below 1.0.
    anomaly_unknown_app: float = 1.3   # no declared context = mild elevation

    # === LEARNED BIAS — the only term that can lower the score ===============
    # bias = 1 - routine * (1 - floor); routine grows with benign repetition.
    # bias is floored by the static band so a dangerous cell can never be
    # normalised to "safe" no matter how routine it becomes (the safety
    # asymmetry, relocated out of deviation where it used to double-count).
    bias_decay_k: float = 0.15         # how fast repetition builds "routine"
    bias_floor: dict[str, float] = field(
        default_factory=lambda: {"critical": 0.75, "high": 0.75, "medium": 0.5, "low": 0.4}
    )
    bias_min_observations: int = 5     # below this, bias stays 1.0 (trust gate)

    # --- decision thresholds (fraction of the artifact's score_max) ----------
    degrade_frac: float = 0.25
    drop_frac: float = 0.55
    # a first-ever call is never silently allowed.
    novelty_min_action: str = "degrade"
    # only allowed/degraded calls train the benign baseline; dropped ones never do.
    learn_on_degrade: bool = True

    # --- state backend -------------------------------------------------------
    state_backend: str = "memory"  # "memory" | "redis"
    redis_url: str = "redis://127.0.0.1:6379/0"
    state_namespace: str = "mcpgw"
    # decay observations older than this many seconds when computing counts (0 =
    # never forget). Lets a baseline age out so a long-idle pattern re-flags.
    baseline_ttl_seconds: int = 0

    @classmethod
    def from_env(cls, prefix: str = "MCPGW_") -> "GatewayConfig":
        cfg = cls()
        for f in cfg.__dataclass_fields__:
            env = os.environ.get(prefix + f.upper())
            if env is None:
                continue
            cur = getattr(cfg, f)
            if isinstance(cur, bool):
                setattr(cfg, f, env.lower() in ("1", "true", "yes"))
            elif isinstance(cur, int) and not isinstance(cur, bool):
                setattr(cfg, f, int(env))
            elif isinstance(cur, float):
                setattr(cfg, f, float(env))
            elif isinstance(cur, str):
                setattr(cfg, f, env)
        return cfg
