"""Resolve a live call to the asset it touches — MCP-AGNOSTIC by default.

The default resolver AUTO-DERIVES which argument locates the asset from the static
scan itself (``artifact.tool_input_ranking``): the highest-risk string input that
is not a destination/sink is the asset locator. This works for any MCP — path,
repo, channel, account — with no per-kind code, because the scan already ranked
the inputs. Hierarchical assets (paths ``a/b/c``, repos ``org/repo``, channels
``ws#chan``) resolve by exact match then longest scored parent.

Per-kind resolver classes remain as OPTIONAL overrides: register one only if a
domain needs logic the scan can't express (e.g. pulling a table name out of a raw
SQL string). Absent an override, the auto-resolver handles the MCP.
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod

from .artifact import StaticArtifact

# argument names that name a DESTINATION / sink, not the asset acted on.
_DEST_NAMES = ("destination", "dest", "to", "target", "recipient", "payee",
               "visibility", "audience", "to_account")
_SEPARATORS = ("/", ":", "#")


class AssetResolver(ABC):
    kind: str = "generic"

    @abstractmethod
    def resolve(self, tool: str, args: dict, artifact: StaticArtifact) -> str | None:
        """Return the asset_id this call touches, or None if undeterminable."""

    @staticmethod
    def _match_ids(candidates: list[str], asset_ids: list[str]) -> str | None:
        # exact / tail / substring match first (specific → loose)
        for aid in asset_ids:
            for cand in candidates:
                if aid == cand:
                    return aid
        for aid in asset_ids:
            for cand in candidates:
                tail = cand.rsplit("/", 1)[-1]
                if aid == tail or tail == aid:
                    return aid
        for aid in asset_ids:
            for cand in candidates:
                if aid in cand:
                    return aid
        return None

    @staticmethod
    def _resolve_hierarchical(cand: str, artifact: StaticArtifact) -> str | None:
        """Longest scored parent for a hierarchical id (path/repo/channel)."""
        if not any(sep in cand for sep in _SEPARATORS):
            return None
        c = cand.lstrip("/")
        parents = sorted(
            (a for a in artifact.asset_ids
             if any(sep in a for sep in _SEPARATORS)
             and (c + "/").startswith(a.lstrip("/")) or c.startswith(a.lstrip("/"))),
            key=len, reverse=True,
        )
        for p in parents:                       # prefer a parent with a scored row
            if p in artifact.table.get("cells", {}):
                return p
        return parents[0] if parents else None


class AutoResolver(AssetResolver):
    """MCP-agnostic default: derive the asset-locating argument from the scan's
    input ranking, excluding destination/sink args, then match its value against
    the asset ids (with hierarchical parent inheritance)."""

    kind = "generic"

    def _locator_args(self, tool: str, artifact: StaticArtifact) -> list[str]:
        inputs = artifact.critical_triggers(tool)  # tool_input_ranking[tool].inputs
        ranked = [
            i["name"] for i in sorted(inputs, key=lambda x: -x.get("risk", 0))
            if i.get("name") not in _DEST_NAMES
            and i.get("type") in ("string", "array", None)
        ]
        # generic fallbacks common across MCPs when the scan didn't rank inputs
        return ranked or ["path", "source", "repo", "channel", "account", "id", "table"]

    def resolve(self, tool, args, artifact):
        # 1 · try the scan-ranked locating args, in order
        candidates: list[str] = []
        for name in self._locator_args(tool, artifact):
            if name in args:
                v = args[name]
                candidates.extend(str(x) for x in (v if isinstance(v, list) else [v]))
        # 2 · then any remaining string args (still excluding destinations)
        for k, v in args.items():
            if k not in _DEST_NAMES and isinstance(v, str):
                candidates.append(v)

        hit = self._match_ids(candidates, artifact.asset_ids)
        if hit:
            return hit
        for cand in candidates:                 # hierarchical inheritance
            parent = self._resolve_hierarchical(cand, artifact)
            if parent:
                return parent
        # 3 · implicit asset (tool acts on an asset not in its args) from the scan
        implicit = (artifact.table.get("inferred_profile", {})
                    .get("implicit_assets", {}).get(tool))
        if implicit:
            return implicit
        homed = artifact.homed_assets(tool)
        return homed[0] if len(homed) == 1 else None


class SqlResolver(AssetResolver):
    """OPTIONAL override — SQL needs a table pulled out of a raw query string,
    which the scan's input ranking can't name. Register it only for SQL MCPs."""

    kind = "sqlite"
    _TABLE_RE = re.compile(r"\b(?:from|into|update|join|table)\s+[`\"']?([A-Za-z_][\w]*)", re.I)

    def resolve(self, tool, args, artifact):
        cands: list[str] = []
        if "table" in args:
            cands.append(str(args["table"]))
        for v in args.values():
            if isinstance(v, str) and " " in v:
                cands += self._TABLE_RE.findall(v)
        cands += [str(v) for v in args.values() if isinstance(v, str)]
        return self._match_ids(cands, artifact.asset_ids)


# The registry maps an MCP kind → an OVERRIDE resolver. Any kind not listed uses
# the auto-resolver, so filesystem/slack/github/payment/google all work with no
# entry here. Add an override only when a domain needs non-derivable logic.
_AUTO = AutoResolver()
_REGISTRY: dict[str, AssetResolver] = {
    "sqlite": SqlResolver(),
}


def resolver_for(kind: str) -> AssetResolver:
    """The override resolver for an MCP kind, or the agnostic auto-resolver."""
    return _REGISTRY.get(kind, _AUTO)


def register_resolver(resolver: AssetResolver) -> None:
    """Plug in an override resolver for a specific MCP kind."""
    _REGISTRY[resolver.kind] = resolver
