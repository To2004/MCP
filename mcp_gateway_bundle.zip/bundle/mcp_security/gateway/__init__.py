"""Runtime dynamic misuse gateway.

Sits in front of a trusted MCP server, scores every observed call against the
static scan artifact, and enforces an allow / degrade / drop decision — with no
LLM on the hot path.

The pieces (each its own module, so they can be swapped and tested in isolation):

    config       GatewayConfig — every tunable knob in one place.
    artifact     StaticArtifact — loads/validates a static scan, exposes the
                 ceiling lookup and tool→asset homing.
    resolve      AssetResolver — maps (tool, args) → the asset actually touched;
                 one implementation per MCP kind, chosen by artifact.server_kind.
    state        BaselineStore — the per-app behavioural baseline; in-memory for
                 dev, Redis for production. This is the stateful heart.
    likelihood   the four factors (deviation / anomaly / exposure / escalation)
                 as separate LikelihoodFactor components, composed by an engine.
    scorer       DynamicScorer — orchestrates resolve → ceiling → likelihood →
                 decide. Pure, deterministic, fast.
    decision     Decision + Action + the banding/enforcement policy.
    interceptor  GatewayMiddleware — the actual call-interception hook that wraps
                 the scorer, applies enforcement, and emits an audit record.
    audit        structured decision logging.

The offline half lives in ``mcp_security.app_context``: the LLM compiler that
turns an app's high-level context into the expected-op/asset sets the anomaly
factor checks at runtime.
"""

from .config import GatewayConfig
from .decision import Action, Decision
from .scorer import DynamicScorer, ScoringContext
from .interceptor import GatewayMiddleware, GatewayResult

__all__ = [
    "GatewayConfig",
    "Action",
    "Decision",
    "DynamicScorer",
    "ScoringContext",
    "GatewayMiddleware",
    "GatewayResult",
]
