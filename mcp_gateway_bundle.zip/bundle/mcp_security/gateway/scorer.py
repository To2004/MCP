"""DynamicScorer — resolve → ceiling → likelihood → decide, for one call.

Pure and deterministic: given the same artifact, config, and baseline state, the
same call yields the same decision. The only state it touches is the BaselineStore
(read to score, written to learn), and only through its interface.
"""

from __future__ import annotations

from .artifact import StaticArtifact
from .config import GatewayConfig
from .decision import Action, Decision, band_and_action
from .likelihood import LikelihoodEngine, ScoringContext
from .likelihood.engine import default_factors
from .likelihood.exposure import FlowZones
from .resolve import AssetResolver, resolver_for
from .state import BaselineStore, make_store

# re-export so callers can `from ...scorer import ScoringContext`
__all__ = ["DynamicScorer", "ScoringContext"]


class DynamicScorer:
    def __init__(
        self,
        artifact: StaticArtifact,
        config: GatewayConfig | None = None,
        *,
        store: BaselineStore | None = None,
        engine: LikelihoodEngine | None = None,
        resolver: AssetResolver | None = None,
        flow_zones: FlowZones | None = None,
    ) -> None:
        self.artifact = artifact
        self.config = config or GatewayConfig()
        self.store = store or make_store(self.config)
        self.engine = engine or LikelihoodEngine(default_factors(flow_zones))
        self.resolver = resolver or resolver_for(artifact.server_kind)

    def _bias(self, app_id: str, tool: str, asset: str | None, band: str) -> float:
        """Learned routine-discount in [floor, 1]. Grows with benign repetition
        but is floored by the static band, so high-ceiling cells relax only to
        their floor (e.g. 0.75) and never to 'safe'. Below a trust gate of
        min_observations it stays 1.0 so a few early calls can't skew it."""
        import math

        cfg = self.config
        if asset is None:
            return 1.0  # unresolved asset: never discount a call we couldn't pin
        n = self.store.count(app_id, tool, asset)
        if n < cfg.bias_min_observations:
            return 1.0
        b = (band or "medium").split()[0]
        floor = cfg.bias_floor.get(b, 0.5)
        routine = 1.0 - math.exp(-cfg.bias_decay_k * n)  # 0 → 1 as n grows
        return 1.0 - routine * (1.0 - floor)

    def score(self, app_id: str, tool: str, args: dict | None = None, *, learn: bool = True) -> Decision:
        args = args or {}

        # 1 · resolve the asset the call touches
        asset = self.resolver.resolve(tool, args, self.artifact)

        # 2 · look up the ceiling (fall back to the tool's worst cell if unresolved)
        ceiling, band = self.artifact.ceiling(tool, asset)
        if ceiling is None:
            ceiling, band, guessed = self.artifact.worst_ceiling_for_tool(tool)
            band = band or ""
            if asset is None:
                asset = guessed  # best-effort, for the audit trail

        # 3 · compute likelihood from the live call
        ctx = ScoringContext(
            app_id=app_id,
            tool=tool,
            args=args,
            asset=asset,
            ceiling=ceiling,
            static_band=band,
            artifact=self.artifact,
            store=self.store,
            config=self.config,
            app_context=self.store.get_app_context(app_id),
            primary_op=self.artifact.primary_op(tool),
        )
        lk = self.engine.evaluate(ctx)
        novel = not self.store.seen_tool(app_id, tool)

        # 3b · learned bias — the ONLY term that can lower the score. Floored by
        # the static band so a dangerous cell can never be normalised to "safe"
        # by repetition (the safety asymmetry, relocated out of the deviation
        # factor where it used to double-count).
        bias = self._bias(app_id, tool, asset, band)

        # 4 · decide  —  score = ceiling × likelihood × escalation × bias
        final = ceiling * lk.likelihood * lk.escalation * bias
        band_out, action = band_and_action(
            final,
            self.artifact.score_max,
            degrade_frac=self.config.degrade_frac,
            drop_frac=self.config.drop_frac,
            novel=novel,
            novelty_min=Action(self.config.novelty_min_action),
            floor=lk.floor_action,
        )
        reasons = (["first-ever call by this app (cold-start)"] if novel else []) + lk.reasons

        decision = Decision(
            app_id=app_id,
            tool=tool,
            asset=asset,
            artifact_version=self.artifact.version,
            static_ceiling=ceiling,
            static_band=band or "n/a",
            factors=lk.factor_values,
            likelihood=lk.likelihood,
            param_escalation=lk.escalation,
            bias=bias,
            final_score=final,
            band=band_out,
            action=action,
            novel=novel,
            reasons=reasons,
        )

        # 5 · learn — only benign (allowed/degraded) calls on a real asset train
        # the baseline; a dropped call must never teach the model it is routine.
        if learn and asset is not None and action != Action.DROP:
            if action == Action.ALLOW or self.config.learn_on_degrade:
                self.store.observe(app_id, tool, asset)

        return decision
