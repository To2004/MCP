"""Load, validate and query a static scan artifact.

The gateway never re-derives risk; it looks it up. This wraps the JSON that
``mcp_security.scanner.scan_server`` / ``static_pipeline.run_static_scan`` writes
and exposes exactly what the runtime needs: the (tool, asset) ceiling, the band,
the tool→asset homing, the atomic op per tool, and the per-parameter critical
triggers. A malformed or empty artifact raises here, not deep in the scorer.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path


class ArtifactError(ValueError):
    """The static artifact is missing required fields to score against."""


@dataclass
class StaticArtifact:
    table: dict
    version: str  # sha256 of the file, so a decision cites the exact matrix it used

    # ------------------------------------------------------------------ load
    @classmethod
    def load(cls, path: str | Path) -> "StaticArtifact":
        p = Path(path)
        if not p.exists():
            raise ArtifactError(f"no static artifact at {p}")
        raw = p.read_bytes()
        table = json.loads(raw)
        version = hashlib.sha256(raw).hexdigest()[:16]
        return cls.from_table(table, version=version)

    @classmethod
    def from_table(cls, table: dict, *, version: str = "inline") -> "StaticArtifact":
        for key in ("cells", "asset_ids"):
            if key not in table:
                raise ArtifactError(f"artifact missing '{key}'")
        art = cls(table=table, version=version)
        if not art.tools:
            raise ArtifactError("artifact has no tools in its matrix")
        return art

    # ------------------------------------------------------------- properties
    @property
    def server(self) -> str:
        return self.table.get("server", "unknown")

    @property
    def server_kind(self) -> str:
        return self.table.get("server_kind", "generic")

    @property
    def score_max(self) -> int:
        return self.table.get("score_max", 75)

    @property
    def asset_ids(self) -> list[str]:
        return self.table.get("asset_ids") or list(self.table.get("cells", {}))

    @property
    def tools(self) -> list[str]:
        cells = self.table.get("cells", {})
        return list(next(iter(cells.values())).keys()) if cells else []

    # ------------------------------------------------------------- lookups
    def ceiling(self, tool: str, asset: str | None) -> tuple[float | None, str]:
        """The (tool, asset) ceiling and its band, or (None, '') if the pair is N/A."""
        cells = self.table.get("cells", {})
        bands = self.table.get("bands", {})
        if asset is not None and cells.get(asset, {}).get(tool) is not None:
            return cells[asset][tool], bands.get(asset, {}).get(tool, "")
        return None, ""

    def worst_ceiling_for_tool(self, tool: str) -> tuple[float, str, str | None]:
        """The highest cell this tool has across any asset — the conservative
        answer when the asset could not be resolved from the arguments."""
        cells = self.table.get("cells", {})
        bands = self.table.get("bands", {})
        best, best_asset = -1.0, None
        for a in self.asset_ids:
            v = cells.get(a, {}).get(tool)
            if v is not None and v > best:
                best, best_asset = v, a
        if best_asset is None:
            return 0.0, "", None
        return best, bands.get(best_asset, {}).get(tool, ""), best_asset

    def homed_assets(self, tool: str) -> list[str]:
        """Assets whose cell for this tool is not None (the tool can act on them)."""
        cells = self.table.get("cells", {})
        return [a for a in self.asset_ids if cells.get(a, {}).get(tool) is not None]

    def primary_op(self, tool: str) -> str | None:
        return self.table.get("tool_impact_detail", {}).get(tool, {}).get("primary_op")

    def critical_triggers(self, tool: str) -> list[dict]:
        """Per-parameter {name, critical_trigger, risk} from the static input ranking."""
        return self.table.get("tool_input_ranking", {}).get(tool, {}).get("inputs", [])
