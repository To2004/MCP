"""GatewayMiddleware — the interception point in front of the MCP server.

This is what turns the scorer into a gateway. It sits on the path a JSON-RPC
``tools/call`` takes to the server, scores it, and enforces the decision:

    ALLOW    → forward to the server unchanged.
    DEGRADE  → forward, but under a constraint (require approval, cut scope,
               rate-limit). The constraint is policy; a hook is provided.
    DROP     → do not forward; return a JSON-RPC error to the agent.

Transport-agnostic: it takes an already-parsed call and a ``forward`` callable,
so it drops into a stdio proxy, an HTTP/SSE proxy, or an in-process wrapper alike.
Wiring to a specific MCP transport is the one integration point left to the host.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Protocol

from .audit import AuditLog
from .decision import Action, Decision
from .scorer import DynamicScorer


class ApprovalHook(Protocol):
    def __call__(self, decision: Decision, call: "MCPCall") -> bool:
        """Return True to let a DEGRADE-classified call proceed (e.g. a human
        approved it, or a step-up auth succeeded), False to block it."""


@dataclass
class MCPCall:
    """A parsed ``tools/call`` request, with the app/agent identity attached by
    the transport layer (from the session/auth, not from the payload)."""

    app_id: str
    tool: str
    arguments: dict
    request_id: Any = None


@dataclass
class GatewayResult:
    decision: Decision
    forwarded: bool
    response: Any = None  # the server's response when forwarded, else an error object


class GatewayMiddleware:
    def __init__(
        self,
        scorer: DynamicScorer,
        *,
        audit: AuditLog | None = None,
        on_degrade: ApprovalHook | None = None,
    ) -> None:
        self.scorer = scorer
        self.audit = audit or AuditLog()
        # default degrade policy: allow through but flagged. Override to require
        # step-up auth / human approval / scope reduction.
        self.on_degrade = on_degrade

    def handle(self, call: MCPCall, forward: Callable[[MCPCall], Any]) -> GatewayResult:
        """Score one call and enforce. ``forward`` actually sends it to the server."""
        decision = self.scorer.score(call.app_id, call.tool, call.arguments)
        self.audit.record(decision)

        if decision.action == Action.DROP:
            return GatewayResult(decision, forwarded=False, response=self._blocked(call, decision))

        if decision.action == Action.DEGRADE:
            approved = self.on_degrade(decision, call) if self.on_degrade else True
            if not approved:
                return GatewayResult(
                    decision, forwarded=False, response=self._blocked(call, decision)
                )

        return GatewayResult(decision, forwarded=True, response=forward(call))

    @staticmethod
    def _blocked(call: MCPCall, decision: Decision) -> dict:
        """A JSON-RPC-style error the agent receives instead of the tool result."""
        return {
            "jsonrpc": "2.0",
            "id": call.request_id,
            "error": {
                "code": -32001,
                "message": f"blocked by misuse gateway ({decision.band})",
                "data": {
                    "action": decision.action.value,
                    "score": round(decision.final_score, 2),
                    "reasons": decision.reasons,
                    "artifact": decision.artifact_version,
                },
            },
        }
