"""Structured decision logging.

Every gateway decision is auditable: which artifact version, which factors, which
action, and why. Default sink is the stdlib logger as one JSON line per decision;
swap in a file/Kafka/OTel sink by passing another ``emit`` callable.
"""

from __future__ import annotations

import json
import logging
from typing import Callable

from .decision import Decision

logger = logging.getLogger("mcp_security.gateway.audit")


class AuditLog:
    def __init__(self, emit: Callable[[dict], None] | None = None) -> None:
        self._emit = emit or self._default_emit

    @staticmethod
    def _default_emit(record: dict) -> None:
        logger.info("decision %s", json.dumps(record, default=str))

    def record(self, decision: Decision) -> None:
        self._emit(decision.to_audit())
