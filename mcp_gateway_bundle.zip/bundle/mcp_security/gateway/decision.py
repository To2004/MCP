"""The decision the gateway returns for one call, plus banding/enforcement."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


class Action(str, Enum):
    ALLOW = "allow"
    DEGRADE = "degrade"  # let it through under a constraint (approval, scope cut, rate-limit)
    DROP = "drop"  # block the call, return an error to the agent

    def _rank(self) -> int:
        return {"allow": 0, "degrade": 1, "drop": 2}[self.value]

    def escalate_to(self, other: "Action") -> "Action":
        """Return the more severe of two actions (a floor never lowers)."""
        return self if self._rank() >= other._rank() else other


@dataclass
class FactorResult:
    """One likelihood factor's output. ``floor_action`` lets a factor demand a
    minimum enforcement regardless of the multiplicative score (e.g. a confirmed
    exfil flow)."""

    name: str
    value: float
    reasons: list[str] = field(default_factory=list)
    floor_action: Action | None = None


@dataclass
class Decision:
    app_id: str
    tool: str
    asset: str | None
    artifact_version: str
    static_ceiling: float
    static_band: str
    factors: dict[str, float]
    likelihood: float
    param_escalation: float
    bias: float
    final_score: float
    band: str
    action: Action
    novel: bool
    reasons: list[str] = field(default_factory=list)
    ts: float = field(default_factory=time.time)

    def to_audit(self) -> dict:
        return {
            "ts": self.ts,
            "app": self.app_id,
            "tool": self.tool,
            "asset": self.asset,
            "artifact": self.artifact_version,
            "ceiling": self.static_ceiling,
            "static_band": self.static_band,
            "factors": self.factors,
            "likelihood": round(self.likelihood, 4),
            "escalation": self.param_escalation,
            "bias": round(self.bias, 4),
            "score": round(self.final_score, 2),
            "band": self.band,
            "action": self.action.value,
            "novel": self.novel,
            "reasons": self.reasons,
        }

    def explain(self) -> str:
        f = self.factors
        return (
            f"{self.action.value.upper():7} score={self.final_score:6.1f} band={self.band:8} "
            f"| ceiling={self.static_ceiling:g}({self.static_band}) × L={self.likelihood:.2f} "
            f"[{' '.join(f'{k}={v:.2f}' for k, v in f.items())}] × esc={self.param_escalation:.2f} "
            f"× bias={self.bias:.2f}"
            + (f"  {'; '.join(self.reasons)}" if self.reasons else "")
        )


def band_and_action(
    score: float,
    score_max: float,
    *,
    degrade_frac: float,
    drop_frac: float,
    novel: bool,
    novelty_min: Action,
    floor: Action | None,
) -> tuple[str, Action]:
    frac = score / score_max if score_max else 0.0
    if frac >= drop_frac:
        band, action = "critical", Action.DROP
    elif frac >= degrade_frac:
        band, action = "high", Action.DEGRADE
    elif frac >= degrade_frac / 2:
        band, action = "medium", Action.ALLOW
    else:
        band, action = "low", Action.ALLOW
    if novel and action == Action.ALLOW:
        action = action.escalate_to(novelty_min)
    if floor is not None:
        action = action.escalate_to(floor)
        if action in (Action.DROP, Action.DEGRADE) and band in ("low", "medium"):
            band = "critical" if action == Action.DROP else "high"
    return band, action
