"""Access anomaly — is this operation inside the app's declared purpose?

The app's high-level context was compiled OFFLINE into expected-op and
expected-asset sets (mcp_security.app_context.compiler). At runtime this is cheap
set membership: an op-class or asset the app never declared is out of character —
the "technically allowed but out of character" case from slide 43.
"""

from __future__ import annotations

from ..decision import FactorResult
from .base import LikelihoodFactor, ScoringContext


class AccessAnomalyFactor(LikelihoodFactor):
    kind = "multiplicative"
    name = "anomaly"

    def evaluate(self, ctx: ScoringContext) -> FactorResult:
        # CORRECTED (one-sided): in-scope is NORMAL (1.0) — the absence of an
        # alarm, NOT a reward. Previously in-scope returned 0.25, actively
        # discounting a call to a quarter, which let an attacker who stayed
        # in-declared-scope drive scores down. Out-of-scope raises; two signals
        # (op AND asset both out) raise to STRONG.
        cfg = ctx.config
        appctx = ctx.app_context
        if appctx is None:
            return FactorResult(self.name, cfg.anomaly_unknown_app, ["no declared context for app"])
        reasons: list[str] = []
        hits = 0
        if appctx.expected_ops and ctx.primary_op and ctx.primary_op not in appctx.expected_ops:
            hits += 1
            reasons.append(f"op {ctx.primary_op} outside declared purpose")
        if appctx.expected_assets and ctx.asset and ctx.asset not in appctx.expected_assets:
            hits += 1
            reasons.append(f"asset {ctx.asset} outside declared scope")
        if hits >= 2:
            value = cfg.factor_strong
        elif hits == 1:
            value = cfg.factor_elevated
        else:
            value = cfg.factor_normal
            reasons.append("within declared purpose")
        return FactorResult(self.name, value, reasons)
