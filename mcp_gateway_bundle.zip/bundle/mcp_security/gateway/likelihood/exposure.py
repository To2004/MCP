"""Exposure — the data-flow risk carried by the ACTUAL argument values.

MCP-AGNOSTIC. What counts as a "sensitive origin" and a "public/exposed sink"
differs by domain, so the zone tests are selected per MCP kind from a registry
(filesystem paths, Slack external audiences, GitHub public visibility, payment
unknown payees, Google external shares). The exfil logic is the same everywhere:
a sensitive-origin → exposed-destination flow raises to STRONG and floors the
decision at DROP (its damage is in the flow, not the tool's nominal ceiling).

The zones are chosen from ``ctx.artifact.server_kind``; a scan may also override
them via ``inferred_profile.exposure_zones = {"sensitive": <regex>, "public": <regex>}``.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from ..decision import Action, FactorResult
from .base import LikelihoodFactor, ScoringContext


@dataclass
class FlowZones:
    """Regexes marking sensitive-origin and public/exposed-destination values."""

    sensitive: str = r"(^|/)(private|secret|security|keys?|creds?|confidential|pii)(/|$)"
    public: str = r"(^|/)(public|www|share|external|tmp|outbox|export)(/|$)"

    def is_sensitive(self, v: str) -> bool:
        return bool(re.search(self.sensitive, v, re.I))

    def is_public(self, v: str) -> bool:
        return bool(re.search(self.public, v, re.I))


# per-kind exposure vocabularies — the one thing that genuinely differs by domain.
_ZONES_BY_KIND: dict[str, FlowZones] = {
    "filesystem": FlowZones(),  # the defaults above
    "slack": FlowZones(
        sensitive=r"(exec|finance|legal|security|hr|#priv|confidential)",
        public=r"(external|public-channel|shared-channel|#general|dm-external|guest)",
    ),
    "github": FlowZones(
        sensitive=r"(infra|prod|secret|deploy|security|private)",
        public=r"(public|fork|gist|external)",
    ),
    "payment": FlowZones(
        sensitive=r"(merchant|balance|ledger|card|pan|account)",
        public=r"(external|unknown|new-payee|unverified|payout)",
    ),
    "google": FlowZones(
        sensitive=r"(private|confidential|internal|restricted)",
        public=r"(anyone|public|external|@gmail|@outlook|shared-link|published)",
    ),
    "email": FlowZones(
        sensitive=r"(private|confidential|internal)",
        public=r"(external|@gmail|@outlook|bcc|forward)",
    ),
}


def zones_for(artifact) -> FlowZones:
    """Pick the exposure zones for this MCP: a scan-provided override, else the
    per-kind set, else the filesystem default — so any MCP gets a live factor."""
    override = (getattr(artifact, "table", {}) or {}).get("inferred_profile", {}).get("exposure_zones")
    if override and "sensitive" in override and "public" in override:
        return FlowZones(sensitive=override["sensitive"], public=override["public"])
    return _ZONES_BY_KIND.get(getattr(artifact, "server_kind", ""), FlowZones())


class ExposureFactor(LikelihoodFactor):
    kind = "multiplicative"
    name = "exposure"

    def __init__(self, zones: FlowZones | None = None) -> None:
        # an explicitly injected zones wins; otherwise chosen per-call by MCP kind
        self._fixed_zones = zones

    def _zones(self, ctx: ScoringContext) -> FlowZones:
        return self._fixed_zones or zones_for(ctx.artifact)

    def evaluate(self, ctx: ScoringContext) -> FactorResult:
        # One-sided: benign is NORMAL (1.0); exposure only RAISES. A confirmed
        # sensitive→exposed flow raises to STRONG and floors the decision at DROP.
        cfg = ctx.config
        zones = self._zones(ctx)
        vals = [str(v) for v in ctx.args.values() if isinstance(v, str)]
        srcs = [v for v in vals if zones.is_sensitive(v)]
        dsts = [v for v in vals if zones.is_public(v)]
        # the resolved asset itself may be the sensitive origin (e.g. a channel id)
        if ctx.asset and zones.is_sensitive(str(ctx.asset)):
            srcs.append(str(ctx.asset))
        value = cfg.factor_normal
        floor: Action | None = None
        reasons: list[str] = []

        if srcs and dsts:
            value, floor = cfg.factor_strong, Action.DROP
            reasons.append(f"sensitive→exposed flow ({srcs[0]} → {dsts[0]})")

        # extension / disguise change across two path-like args (filesystem-ish;
        # harmless elsewhere since non-path args rarely have differing extensions).
        exts = [v.rsplit(".", 1)[-1].lower() for v in vals if "." in v.rsplit("/", 1)[-1]]
        if len(set(exts)) > 1 and ctx.asset:
            value = max(value, cfg.factor_elevated)
            floor = floor or Action.DEGRADE
            reasons.append(f"extension/disguise change ({' → '.join(dict.fromkeys(exts))})")

        if srcs and not dsts:
            value = max(value, cfg.factor_elevated)
            reasons.append(f"touches a sensitive zone ({srcs[0]})")

        return FactorResult(self.name, value, reasons, floor_action=floor)
