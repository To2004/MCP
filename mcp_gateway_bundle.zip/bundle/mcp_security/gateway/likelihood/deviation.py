"""Baseline deviation — a one-sided alarm: has this (app, tool, asset) been seen?

CORRECTED (one-sided). Previously this factor was the discount engine: it started
at 1.0 and decayed toward a band-keyed floor, so it did TWO jobs at once — the
"this is new" signal AND the "this is routine, relax it" discount — which
double-counted with the learned relaxation. Now it only RAISES:

    unseen (app, tool, asset)  -> STRONG   (first time this agent touched this)
    rarely seen (< relax)      -> ELEVATED
    established                 -> NORMAL (1.0, no signal)

The routine discount it used to carry now lives solely in the learned `bias`
(state/bias), which is floored so a dangerous cell can't be normalised. Keying on
(app, tool, ASSET) — not just (app, tool) — is deliberate: a first read of the
crown-jewel file is novel even if the agent has read public files with read_file.
"""

from __future__ import annotations

from ..decision import FactorResult
from .base import LikelihoodFactor, ScoringContext

_RELAX_AFTER = 10  # observations by which novelty fully relaxes to NORMAL


class BaselineDeviationFactor(LikelihoodFactor):
    kind = "multiplicative"
    name = "deviation"

    def evaluate(self, ctx: ScoringContext) -> FactorResult:
        cfg = ctx.config
        asset = ctx.asset or "?"
        n = ctx.store.count(ctx.app_id, ctx.tool, asset)
        if n == 0:
            return FactorResult(
                self.name, cfg.factor_strong,
                ["never seen this (app, tool, asset) before"],
            )
        if n < _RELAX_AFTER:
            return FactorResult(
                self.name, cfg.factor_elevated,
                [f"rarely seen (n={n})"],
            )
        return FactorResult(self.name, cfg.factor_normal, [])
