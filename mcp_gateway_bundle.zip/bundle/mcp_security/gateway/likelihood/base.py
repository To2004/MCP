"""Likelihood-factor interface + the per-call scoring context.

RECONSTRUCTED FILE. This module was not among the uploaded sources, so it has
been rebuilt to exactly match how every factor and the scorer use it:
  - ScoringContext fields are those constructed in scorer.DynamicScorer.score()
    and read by the factors (ctx.app_id/tool/args/asset/ceiling/static_band/
    artifact/store/config/app_context/primary_op).
  - LikelihoodFactor is the base every factor subclasses, with a `.kind`
    ("multiplicative" or "amplifier") the engine switches on, a `.name`, and an
    evaluate(ctx) -> FactorResult method.
If you still have the original, replace this file with it — the interface below
is the contract the rest of the package relies on.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class ScoringContext:
    app_id: str
    tool: str
    args: dict
    asset: str | None
    ceiling: float
    static_band: str
    artifact: Any
    store: Any
    config: Any
    app_context: Any = None      # AppContext | None (declared ops/assets)
    primary_op: str | None = None


class LikelihoodFactor:
    """A single likelihood signal. `kind` is 'multiplicative' (bounded into the
    likelihood product) or 'amplifier' (the escalation channel). Each factor is
    one-sided: it returns a value >= 1.0 and can only RAISE risk. The only
    downward force in the model is the learned bias, applied in the scorer."""

    kind: str = "multiplicative"
    name: str = "factor"

    def evaluate(self, ctx: ScoringContext):  # -> FactorResult
        raise NotImplementedError
