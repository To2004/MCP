"""Compose the likelihood factors into (likelihood, escalation, floor, reasons).

Multiplicative factors (deviation × anomaly × exposure) form the likelihood in
[0,1]; amplifier factors (escalation) form a >=1 multiplier on the final score;
any factor may raise a floor action that the decision must honour. The engine is
just this composition, so the set of factors is fully configurable.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..decision import Action, FactorResult
from .anomaly import AccessAnomalyFactor
from .base import LikelihoodFactor, ScoringContext
from .deviation import BaselineDeviationFactor
from .escalation import ParamEscalationFactor
from .exposure import ExposureFactor, FlowZones


@dataclass
class LikelihoodResult:
    likelihood: float
    escalation: float
    factor_values: dict[str, float]
    floor_action: Action | None
    reasons: list[str]


class LikelihoodEngine:
    def __init__(self, factors: list[LikelihoodFactor] | None = None) -> None:
        self.factors = factors or default_factors()

    def evaluate(self, ctx: ScoringContext) -> LikelihoodResult:
        # One-sided factors: each is >= 1.0 and can only RAISE the likelihood.
        # The product is capped (config.likelihood_cap) so a single call cannot
        # run away. The only downward force in the whole model is the learned
        # `bias`, applied separately in the scorer — never here.
        likelihood = 1.0
        escalation = 1.0
        values: dict[str, float] = {}
        reasons: list[str] = []
        floor: Action | None = None
        for factor in self.factors:
            res: FactorResult = factor.evaluate(ctx)
            values[res.name] = res.value
            reasons.extend(res.reasons)
            if res.floor_action is not None:
                floor = res.floor_action if floor is None else floor.escalate_to(res.floor_action)
            if factor.kind == "amplifier":
                escalation *= res.value
            else:
                likelihood *= res.value
        cap = getattr(ctx.config, "likelihood_cap", 3.0)
        likelihood = min(likelihood, cap)
        return LikelihoodResult(likelihood, escalation, values, floor, reasons)


def default_factors(zones: FlowZones | None = None) -> list[LikelihoodFactor]:
    return [
        BaselineDeviationFactor(),
        AccessAnomalyFactor(),
        ExposureFactor(zones),
        ParamEscalationFactor(),
    ]
