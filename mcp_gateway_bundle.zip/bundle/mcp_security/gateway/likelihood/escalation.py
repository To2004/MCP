"""Parameter escalation — a >=1 amplifier when an actual argument VALUE crosses a
critical trigger.

Two sources: the per-parameter ``critical_trigger`` thresholds the static scan
recorded (amount >= 100000, >= 20 recipients, unbounded LIMIT), and a built-in
set of universal amplifiers (scope-widening boolean flags, bulk arrays, large
magnitudes) so a tool with no recorded triggers is still covered.
"""

from __future__ import annotations

import re

from ..decision import FactorResult
from .base import LikelihoodFactor, ScoringContext

_FLAG_HINTS = ("recursive", "force", "cascade", "hard", "permanent", "purge", "all")
_MAG_MONEY = ("amount", "value", "total", "sum")
_MAG_COUNT = ("limit", "count", "max", "perpage", "per_page", "depth", "size")


class ParamEscalationFactor(LikelihoodFactor):
    kind = "amplifier"
    name = "escalation"

    def evaluate(self, ctx: ScoringContext) -> FactorResult:
        mult = 1.0
        reasons: list[str] = []

        for k, v in ctx.args.items():
            kl = k.lower()
            if isinstance(v, bool):
                if v and any(h in kl for h in _FLAG_HINTS):
                    mult = max(mult, 1.5)
                    reasons.append(f"scope-widening flag {k}=true")
            elif isinstance(v, list):
                if len(v) >= 20:
                    mult = max(mult, 1.5)
                    reasons.append(f"bulk fan-out {k}[{len(v)}]")
            elif isinstance(v, (int, float)):
                if any(h in kl for h in _MAG_MONEY) and v >= 100000:
                    mult = max(mult, 1.5)
                    reasons.append(f"{k}={v} ≥ 100000")
                elif any(h in kl for h in _MAG_COUNT) and v >= 100:
                    mult = max(mult, 1.3)
                    reasons.append(f"{k}={v} large")

        # thresholds carried from the static scan's per-parameter ranking
        for entry in ctx.artifact.critical_triggers(ctx.tool):
            trig, name = entry.get("critical_trigger"), entry.get("name")
            if not trig or name not in ctx.args:
                continue
            m = re.search(r"(\d[\d,]*)", str(trig))
            if not m:
                continue
            thr = float(m.group(1).replace(",", ""))
            val = ctx.args[name]
            crossed = (
                (isinstance(val, (int, float)) and not isinstance(val, bool) and val >= thr)
                or (isinstance(val, list) and len(val) >= thr)
            )
            if crossed:
                mult = max(mult, 1.5)
                reasons.append(f"{name} crosses static trigger '{trig}'")

        return FactorResult(self.name, mult, reasons)
