"""Prompt for compiling an app's high-level context into an expected op/asset set.

Run OFFLINE (design time), once per app, alongside the static scan. The output is
the small allow-set the runtime anomaly factor checks by cheap membership — so the
LLM's judgement is spent here, never on the hot path.
"""

APP_CONTEXT_SYSTEM = """You are configuring a misuse gateway that sits in front of \
a trusted MCP server. Given an application's HIGH-LEVEL PURPOSE and the server's \
tool catalog (each tool tagged with its atomic operation class and the assets it \
can touch), decide what this app is NORMALLY EXPECTED to do — so the gateway can \
flag anything out of character. Be tight: include only what the stated purpose \
clearly implies. Output ONLY valid JSON, no prose, no fences."""

APP_CONTEXT_USER = """APPLICATION PURPOSE (its high-level context):
{purpose}

SERVER TOOL CATALOG (tool → atomic op → assets it can touch):
{catalog}

ASSET CLASSES on this server:
{assets}

Decide:
- expected_ops: the atomic operation classes this app legitimately needs (from
  the op classes present in the catalog: READ, LIST, WRITE, MODIFY, DELETE,
  BROADCAST, EXECUTE, TRANSACT, …). A read-only reporting app lists only READ/
  LIST/METADATA; a bot that posts includes BROADCAST; do NOT include DELETE or
  EXECUTE unless the purpose clearly requires it.
- expected_assets: the asset classes the purpose implies it touches. Omit assets
  the purpose gives no reason to touch.
Be conservative — every class you include widens what the gateway treats as
normal. When the purpose is vague, include less.

Return JSON:
{{"expected_ops": [str], "expected_assets": [str], "reasoning": str,
  "confidence": 0.0-1.0}}"""
