"""Compile an app's high-level context into the runtime allow-set (offline, LLM).

For each app the org registers, this reads the app's stated purpose plus the
static scan (to know which ops/assets exist), asks the model what the app is
expected to do, and writes an AppContext into the baseline store. The runtime
anomaly factor then checks membership against it with no LLM call.

A deterministic fallback (verb/keyword heuristic over the purpose text) runs when
the model is unavailable, so an offline pipeline still yields a usable allow-set —
flagged low-confidence for human review.
"""

from __future__ import annotations

import json
import logging

from ..gateway.artifact import StaticArtifact
from ..gateway.state import AppContext, BaselineStore
from .prompts import APP_CONTEXT_SYSTEM, APP_CONTEXT_USER

logger = logging.getLogger(__name__)

# op keywords for the offline fallback
_OP_KEYWORDS = {
    "READ": ("read", "view", "report", "fetch", "get", "show", "look"),
    "LIST": ("list", "browse", "enumerate", "inventory"),
    "SEARCH": ("search", "find", "query", "lookup"),
    "WRITE": ("write", "create", "add", "upload", "save", "record"),
    "MODIFY": ("edit", "update", "modify", "change", "manage"),
    "MOVE": ("move", "rename", "organize", "organise"),
    "DELETE": ("delete", "remove", "clean", "purge", "clear"),
    "BROADCAST": ("post", "send", "notify", "message", "email", "announce", "reply"),
    "EXECUTE": ("run", "execute", "deploy", "build", "trigger"),
    "TRANSACT": ("pay", "transfer", "refund", "charge", "invoice", "settle"),
}


def _catalog_block(artifact: StaticArtifact) -> str:
    lines = []
    for tool in artifact.tools:
        op = artifact.primary_op(tool) or "?"
        assets = artifact.homed_assets(tool)
        lines.append(f"- {tool} → {op} → {', '.join(assets) or 'any'}")
    return "\n".join(lines)


def _heuristic(purpose: str, artifact: StaticArtifact) -> AppContext:
    text = purpose.lower()
    ops = {op for op, kws in _OP_KEYWORDS.items() if any(k in text for k in kws)} or {"READ", "LIST"}
    assets = {a for a in artifact.asset_ids if a.split(".")[0].lower() in text or a.lower() in text}
    return AppContext(app_id="", expected_ops=ops, expected_assets=assets, purpose=purpose)


def compile_app_context(
    app_id: str,
    purpose: str,
    artifact: StaticArtifact,
    *,
    query_llm=None,
    use_llm: bool = True,
) -> AppContext:
    """Produce the AppContext for one app. ``query_llm`` is ollama_client.query_ollama."""
    if use_llm and query_llm is not None:
        prompt = (
            APP_CONTEXT_SYSTEM
            + "\n\n"
            + APP_CONTEXT_USER.format(
                purpose=purpose,
                catalog=_catalog_block(artifact),
                assets=", ".join(artifact.asset_ids),
            )
        )
        reply = query_llm(prompt)
        if isinstance(reply, dict) and "expected_ops" in reply:
            return AppContext(
                app_id=app_id,
                expected_ops={str(o).upper() for o in reply.get("expected_ops", [])},
                expected_assets={str(a) for a in reply.get("expected_assets", [])},
                purpose=purpose,
            )
        logger.warning("app_context: no usable LLM reply for %s; using heuristic", app_id)
    ctx = _heuristic(purpose, artifact)
    ctx.app_id = app_id
    return ctx


def register_app(
    store: BaselineStore,
    app_id: str,
    purpose: str,
    artifact: StaticArtifact,
    *,
    query_llm=None,
    use_llm: bool = True,
) -> AppContext:
    """Compile and persist an app's context into the baseline store."""
    ctx = compile_app_context(app_id, purpose, artifact, query_llm=query_llm, use_llm=use_llm)
    store.put_app_context(ctx)
    logger.info("registered app %s: ops=%s assets=%s", app_id, ctx.expected_ops, ctx.expected_assets)
    return ctx
