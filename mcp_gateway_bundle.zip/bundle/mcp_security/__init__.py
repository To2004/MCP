"""mcp_security — static scan + runtime misuse-scoring gateway for MCP servers."""
