# Embedding Likelihood — Model Package

Two evaluations of the same embedding-based likelihood model (the `likelihood` factor of
the v6 formula `final_risk = static_score x likelihood`), on two synthetic corpora:

| folder | corpus | what it tests |
|---|---|---|
| `original_testbed/` | 20 orgs, external attackers + insiders, ~2,850 calls/server | the standard setting: attacks are a small minority, many by fresh identities |
| `insider_testbed/` | 2 orgs, NO external attackers, 8 personas x ~100 calls each, every persona mixed (~83% benign / ~12% misuse / ~5% attack) | the hard setting: identity carries zero signal; attacks repeat inside the history |

## The model (identical in both folders)

Each call is embedded (hashing vectorizer, 4096-d: tool + argument tokens + structural
flags + magnitude buckets + a `tool|asset` conjunction token), reduced to a 24-d latent
(TruncatedSVD fit on the reference history), scored by mean distance to its 5 nearest
reference calls (self-excluded), calibrated against the reference's own quantiles, and
mapped to `likelihood in [0.1, 1.0]`. No LLM, no labels, deterministic; fit < 0.5 s per
server, scoring ~0.05 ms per call.

Key guards (all label-free and general):

- **Quantile-anchored ramp**: the reference q99 score marks the ramp start (equivalent
  to a conformal p=0.01 threshold); saturation at 1.5x that distance. Both cutoffs were
  tuned on the original corpus ONLY and validated untouched on the insider corpus
  (equal TPR at roughly half the benign FPR vs the previous q98/2.5x setting).
- **Impact-aware reference filter**: calls at/above the scan's *high* band never enter
  the demonstrated-normal reference — repetition cannot buy a crown-asset destructive
  call a discount.
- **Iterated self-trim** (unlabeled streams): the model scores its own history and
  drops what it flags, at 0.8x the ramp start (trimming BELOW the ramp decouples
  contamination control from the alerting cutoff), refitting up to 3 rounds.
- **Cold start**: no/thin history -> likelihood 1.0 (full static risk), decaying only
  as benign history accumulates.

## Files per corpus folder

- `<server>_test.csv` — held-out calls only (never used in fitting), scored by the
  frozen model trained on the benign head of the stream. "The test-set file."
- `<server>_stream.csv` — every call in true arrival order; row 1 is the genuinely
  first call ever seen (likelihood 1.0). The model refits every 50 calls on all prior
  calls, labels never consulted. "The training-from-the-start file."
- `<server>_runs.csv` — one scored line per run/session: persona, category, mean/max
  likelihood, max & sum of final risk, riskiest call. Sorted by max final risk.
- `metrics.json` — per-signal AUCs, TPR/FPR, likelihood means; `stream.mature_half`
  holds the steady-state numbers (past the designed cold-start).

CSV columns: `position, index, run_id, persona, category, tool, args, asset,
static_score, static_basis, z, likelihood, final_risk` where
`final_risk = static_score x likelihood` and `static_basis` marks fallbacks honestly
(`cell` / `tool-worst-case` / `server-worst-case`).

## Headline numbers (kNN architecture fixed a priori; steady-state stream)

| corpus | server | AUC | TPR mal | FPR benign | risk separation |
|---|---|---|---|---|---|
| original | calendar | 0.88 | 81% | 1.0% | x23 |
| original | github | 0.84 | 72% | 2.5% | x13 |
| original | slack | 0.95 | 94% | 2.1% | x27 |
| insider | calendar | 0.51* | 50% | 0.3% | x10 |
| insider | github | 0.71 | 40% | 1.2% | x12 |
| insider | slack | 0.84 | 67% | 0.0% | x18 |

*calendar-insider AUC is rank-order noise at n=24 malicious; its TPR/FPR/separation
hold. Insider TPR is capped by construction: insider sessions are half routine-read
preamble, per-call content-indistinguishable from benign work — catching the *pattern*
is the session-sequence signal's job in the fused pipeline; the per-run rollup
(`_runs.csv`) already ranks attack runs at 2–3x the base rate (top-20: 10–12/20 attacks
vs ~21% base).

## Source

- `model/embedding.py` — the model (`src/mcp_security/dynamic/embedding.py`).
- `model/eval_embedding_likelihood.py` — evaluation + file generation
  (`--variant ins` selects the insider corpus).
- `model/make_insider_testbed.py`, `model/make_dynamic_testbed.py` — corpus generators.
- `EMBEDDING_LIKELIHOOD.md` — the full report: experiment trail (what was tried, kept,
  rejected and why), cutoff optimization protocol, NIST SP 800-30 / OWASP / CVSS
  comparison, per-user-conditioning negative result, insider analysis, related work.
