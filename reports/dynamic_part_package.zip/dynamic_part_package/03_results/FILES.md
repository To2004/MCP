# Results — file guide

Two synthetic corpora (`original_testbed/`, `insider_testbed/`) and the fused evaluation
(`fused/`). Per corpus, three CSV types plus a metrics JSON.

## Per-server CSVs

- **`<server>_test.csv`** — held-out calls only (never used in fitting), scored by the
  frozen model trained on the benign head of the stream. The "test-set" file.
- **`<server>_stream.csv`** — every call in true arrival order; row 1 is the genuinely
  first call ever seen (likelihood 1.0). The model refits every 50 calls on all prior
  calls, labels never consulted. The "training-from-the-start" file.
- **`<server>_runs.csv`** — one scored line per run/session: persona, category, mean/max
  likelihood, max & sum of final risk, riskiest call. Sorted by max final risk. This is
  the session-level view a defender acts on.

### CSV columns (test / stream)

`position, index, run_id, persona, category, tool, args, asset, static_score,
static_basis, z, likelihood, final_risk`

- `category` — BENIGN / MISUSE / MALICIOUS (ground-truth label, never seen by the model).
- `static_score` — the v6 scan cell (impact factor); `static_basis` = `cell` /
  `tool-worst-case` / `server-worst-case` (honest about resolution fallbacks).
- `z` — novelty in ramp-start units (`inf` = no history yet → cold start).
- `likelihood` — in [0.1, 1.0].
- `final_risk = static_score x likelihood`.

## metrics JSON

`metrics.json` (embedding eval) and `metrics_<variant>.json` (fusion) hold per-signal
AUC / TPR / FPR / likelihood means. The `stream.mature_half` block is the steady-state
view (past the designed cold-start) — that is the number to quote, not the full-stream
mix which includes the deliberate likelihood-1.0 warm-up.

## fused/

- `metrics_cbg.json`, `metrics_ins.json` — embed-only vs fused, both corpora, with
  run-level top-20 precision.
- `fused_cbg.log`, `fused_ins.log` — the human-readable run output.
