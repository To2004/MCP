# Dynamic Scoring — Work Documentation

This package documents the **dynamic (runtime) side** of the MCP risk-scoring framework:
the signal that scores each incoming agent tool-call as it happens, complementing the
static design-time scan. It bundles the source, the evaluation harnesses, every result
CSV, the real-traffic validation, and the reports that explain what was tried and why.

Threat model (unchanged): the **MCP server is the protected asset**, the **agent is the
threat**. Dynamic scoring gates/throttles/denies risky calls before execution.

## The core idea

The v6 static scan already computes `risk = asset_sensitivity x blast_radius x
tool_impact x likelihood(1.0)` — with likelihood pinned at 1.0. The dynamic work **fills
that likelihood slot at runtime**:

```
final_risk = static_score x likelihood        likelihood in [0.1, 1.0]
```

`likelihood` is how *normal* this exact call is for this server, learned from the
server's own observed history — no LLM, no labels, deterministic, sub-millisecond to
score. A call indistinguishable from demonstrated-normal traffic keeps 10% of its static
risk; a fully novel one keeps all of it; a call with no history behind it keeps 1.0.

## How to read this package

| folder | contents |
|---|---|
| `01_source/` | the dynamic module: `embedding.py` (the likelihood model), `sequence.py` / `baseline.py` (the other two signals), `combine.py` (fusion), `judge.py` (optional LLM escalator), plus the test suite |
| `02_evaluation_scripts/` | `eval_embedding_likelihood.py` (per-call eval + CSV generation), `eval_fused_likelihood.py` (three-signal fusion), the two testbed generators, and `capture_real_git_mcp.py` (real-traffic capture) |
| `03_results/` | every result CSV + metrics, for both synthetic corpora and the fused evaluation |
| `04_real_data/` | 400 real calls from a live git MCP server + the calibration/featurizer validation report |
| `05_reports/` | `EMBEDDING_LIKELIHOOD.md` (the full technical report + experiment trail) and the design doc |

Start with `05_reports/EMBEDDING_LIKELIHOOD.md` — it has the complete experiment trail
(what was kept, what was rejected, and the evidence for each).

## The model (embedding likelihood)

Each call → bag-of-tokens (tool + argument keys + tokenized values + structural flags +
magnitude buckets + a `tool|asset` conjunction) → 4096-d hashing vectorizer → 24-d
TruncatedSVD latent (fit on the reference history) → **mean distance to the 5 nearest
reference calls** (kNN novelty, self-excluded) → quantile-anchored calibration →
`likelihood in [0.1, 1]`.

Four label-free guards, each earned by an experiment:

1. **Quantile-anchored ramp** — the reference's q99 score marks the ramp start
   (equivalent to a conformal p=0.01 threshold); saturates at 1.5x. Cutoffs tuned on the
   original corpus only, validated untouched on the insider corpus.
2. **Impact-aware reference filter** — calls at/above the scan's *high* band never enter
   the demonstrated-normal reference, so a crown-asset destructive call cannot earn a
   discount by repetition.
3. **Iterated self-trim** (unlabeled streams) — the model drops the history it itself
   flags (below the ramp start), refit up to 3 rounds; ITSR-style contamination control.
4. **Cold start** — no/thin history → likelihood 1.0.

Architecture (kNN) was chosen from an 8-way bake-off (LOF, Isolation Forest,
kth-distance, TF-IDF, autoencoders, surprisal) and is **fixed a priori** across corpora —
re-picking per corpus from held-out labels would be test-set model selection.

## Headline results (kNN, steady-state stream)

| corpus | server | AUC | TPR(mal) | FPR | risk separation |
|---|---|---|---|---|---|
| original | calendar | 0.88 | 81% | 1.0% | x23 |
| original | github | 0.84 | 72% | 2.5% | x13 |
| original | slack | 0.95 | 94% | 2.1% | x27 |
| insider | calendar | 0.51* | 50% | 0.3% | x10 |
| insider | github | 0.71 | 40% | 1.2% | x12 |
| insider | slack | 0.84 | 67% | 0.0% | x18 |

The **insider corpus** (2 orgs, 8 personas x ~100 calls, every persona mixed, no external
attackers) is the hard case: it removes the "fresh attacker identity" artifact so the
model must separate categories from behavior alone. It exposed the likelihood's operating
envelope — a *demonstrated-normal discount*, strong when attacks are rare/curated,
deliberately conservative (never fully vouching) when attacks saturate the history.
*calendar-insider AUC is rank noise at n=24 malicious; its TPR/FPR/separation hold.

## Two closing findings

**Signal fusion** (`eval_fused_likelihood.py`, `03_results/fused/`): fusing the embedding
with sequence + baseline signals, escalate-only. Verdict:
- **Sequence fusion — adopt unconditionally**: calendar-insider AUC 0.51 → 0.75 at zero
  FPR cost (catches read-then-exfil preambles by *order*, which content can't see).
- **Baseline fusion — needs a history-maturity gate**: triples misuse recall but
  explodes FPR to 9–14% on many thin-history personas; safe only after N sessions.
- Run-level, fusion pushes top-20 riskiest runs to 20/20 attacks on every original-corpus
  server — the metric a defender acts on.

**Real-traffic validation** (`04_real_data/`): 400 real calls from a live local
`mcp-server-git` (no external auth; live GitHub/Slack/Calendar tokens are all expired).
The q99 calibration transferred untouched — **real benign FPR 0.8%** — and the featurizer
survived real argument diversity. It also caught a bug: git SHAs (40-char hex) were
tripping the base64-payload flag, now fixed to exclude pure hex.

## Reproduce

```
# generate the corpora
uv run python scripts/make_dynamic_testbed.py
uv run python scripts/make_insider_testbed.py
# evaluate (writes the CSVs in 03_results/)
uv run python scripts/eval_embedding_likelihood.py                    # original
uv run python scripts/eval_embedding_likelihood.py --variant ins ...  # insider
uv run python scripts/eval_fused_likelihood.py [--variant ins]        # fusion
# real-traffic capture + the validation is in 04_real_data/
uv run python scripts/capture_real_git_mcp.py --repo <repo> --n 400
# tests
uv run pytest tests/test_dynamic_embedding.py
```

All results are deterministic under fixed seeds. Fit < 0.5 s/server; scoring ~0.05
ms/call (semi-runtime: refit periodically, score live).
