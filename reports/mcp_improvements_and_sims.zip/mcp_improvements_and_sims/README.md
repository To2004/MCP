# MCP scanner improvements + new simulations

This package contains two deliverables:

1. **Scanner improvements** — see `reports/scanner_improvements_report.md`
   (5 improvements: breadth signal, directory-scope assets, multi-rater oracle,
   pre-commit gate, formula sensitivity).
2. **New simulations** across the big MCPs — see `reports/new_simulations_report.md`
   (Google Calendar, GitHub, Slack, fintech filesystem, devops SQLite).

## Layout
- `reports/`     — the two reports (what changed, why, measured effect, end-to-end).
- `code/`        — the changed/added source and scripts that implement the work.
- `evaluation/`  — multi-rater agreement, accuracy, formula-sensitivity outputs.
- `scans/`       — the static risk-matrix artifacts the scanner produced.
- `sessions/`    — the captured agent-call streams (the ranking corpus inputs).
- `stores/`      — the new on-disk asset stores (fintech filesystem, devops db).
- `ranked_calls.csv` — every captured call scored against its scan.
