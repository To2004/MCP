# All static scans — scan-rules-v4 (judge-validated), 4 formats each

13 scans (3 real + 10 demo). Pipeline: blast 1-5, ONE-CALL rule + breadth limits,
concrete sensitivity anchors, judge off (eval-only, fair — same rules as proposer).
Validated by 4 fair-judge iterations on corp+github: sensitivity 21->90%,
blast 27->71% agreement; consistency findings 151->80 (residual = metadata-op
cells the LLM scores blast 4, documented limitation). Bands are visualization
only; the number (score = sensitivity*blast*impact) drives ranking.
