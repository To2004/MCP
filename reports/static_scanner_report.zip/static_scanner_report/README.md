# Static Scanner — Report & Audit Bundle (refreshed)

Matches the repo's current reports/ exactly (an earlier build of this zip was
stale — the report had been updated after zipping).

- STATIC_SCANNER_REPORT.md  — full report: architecture, scoring model, coverage
  (incl. demo-vs-real tool counts), validation, honest caveats
- static_check/             — fresh-org static-scoring honesty audit + per-call CSV
- influential_inputs/        — which tool INPUTS are risky, ranked by band-swing

The scanner identifies risky tool inputs (influential_inputs) and classifies
tools into atomic operations (src/mcp_security/atomic_ops). See the report for
how each works.
