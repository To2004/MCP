# Static Scanner — Report & Audit Bundle

The full write-up of the static scanning/scoring subsystem plus the audits run
to check it is general and not overfit.

## Contents

```
STATIC_SCANNER_REPORT.md      the big report: architecture, scoring model,
                              coverage (10 servers, 1700 cells), validation, limits
static_check/
  SUMMARY.md                  fresh-org ("NovaCorp") static-scoring honesty audit
  static_scores.csv           the per-call scores from that audit
influential_inputs/
  SUMMARY.md                  most influential input parameters, ranked
  influential_inputs.json     the raw data
```

## Key audit findings (in the report)

- The scorer is **faithful, not hardcoded**: unknown asset -> unresolved,
  unknown tool -> invalid; it never fabricates a score.
- **No data leakage**: no scoring source reads the ground-truth tables
  (the project's own `review verify` guard passes 8/8); all 10 scans are
  LLM-built (`model_reviewed=True`).
- **Honest caveat**: ~52% of band labels are per-cell LLM judgement, so bands
  are not reproducible across rescans; the formula is fragile to +/-1 changes.

## Reproduce the audits

```bash
uv run python scripts/check_static_scoring.py          # fresh-org honesty audit
uv run python scripts/highlight_influential_inputs.py  # influential inputs
uv run python -m mcp_security.review verify            # anti-leakage guard
```
