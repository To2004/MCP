# Static Scanner report bundle — matches repo. Now includes atomic-op flags (§5a) + per-tool input ranking (§5b).
