# Static Scanner bundle — matches repo. §5a atomic-op flag (rules), §5b input ranking (LLM + rule fallback).
