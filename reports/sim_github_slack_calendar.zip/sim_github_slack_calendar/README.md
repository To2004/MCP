# Big-MCP Simulation Bundle — GitHub / Slack / Calendar

Synthetic agent tool-call logs for the three big MCPs, plus the static scan
matrices they were scored against and the benign-vs-misuse-vs-adversarial
separation result.

## What this is (honest scope)

- **Synthetic, not live.** The calls were generated programmatically by
  `scripts/make_dynamic_testbed.py` from the servers' real scan matrices — no
  live GitHub/Slack/Google-Calendar server was run, and no real API call was
  made. Every call still resolves to a real scanned asset, so its risk is real.
- **Really scored.** `scripts/evaluate_dynamic.py` actually ran over these logs;
  the numbers in `dynamic_eval/SUMMARY.md` are reproducible from this bundle.
- Deterministic (seeded) — re-running the generator reproduces these exact rows.

## The four session classes

Sessions model a **realistic organization**, not just attacks. Most activity is
ordinary work; mistakes are the tail, and true attacks are rarer still.

- **benign** — role personas doing normal work. Not just single reads: a mix of
  *simple* actions (a lone read) and *advanced*, multi-step workflows
  (read → open PR; find-free-slot → create event → invite; read history → post
  → reply), all with realistic arguments (`title`/`body`, `content`, `text`,
  `limit`, `attendees`). Benign never touches a destructive tool.
- **misuse** — a *legitimate* persona making an accidental, authorised-but-
  mistaken call that still influences an asset. The negligent/accidental
  insider, **not** an attacker: no exfiltration, just a slip. Three impact
  tiers (encoded in the `run_id`: `misuse_low_* / misuse_medium_* /
  misuse_high_*`):
  - `low` — fat-finger on a trivial asset (delete a `holidays` event, post to
    the wrong low-traffic channel);
  - `medium` — wrong mid-sensitivity target or over-broad scope (edit a shared
    doc without checking, invite ~10-18 people, pull 100-200 messages);
  - `high` — destructive or mass op on a crown jewel: `delete_all_events` on the
    exec calendar, `delete_file` on `infra-config`, an unreviewed
    `merge_pull_request` to prod, a whole-org mis-invite, a sensitive post
    landing in `exec-private`/`hr-internal`.
  Each misuse call carries a plain-language `_mistake` note in its args so a
  judge sees *error, not intent*.
- **insider** — a trusted persona goes rogue: reads a crown jewel then
  exfiltrates it (baseline deviation + read-then-send sequence).
- **external** — a fresh `Attacker` persona: mass crown reads, exfil,
  destructive ops.

## Contents

```
sessions/
  dyn_github_cbg/calls.csv     (20 orgs, benign + misuse + insider + external)
  dyn_slack_cbg/calls.csv
  dyn_calendar_cbg/calls.csv
scan/
  github_cbg.json   + _params.json     the risk matrix + input-parameter rubric
  slack_cbg.json    + _params.json
  calendar_cbg.json + _params.json
dynamic_eval/
  SUMMARY.md            benign / misuse / adversarial separation
  discrimination.json   the raw metrics
```

## CSV columns (calls.csv)

`timestamp, index, persona, category, status, tool, args, run_id`

- `category` — `BENIGN`, `MISUSE`, or `MALICIOUS` (the label, baked in by
  construction).
- `run_id` — `benign_* / misuse_{low,medium,high}_* / insider_* / external_*`
  per org, so sessions (and misuse tiers) are separable.
- `persona` — `Role@org` (e.g. `Analyst Bot@acme`). Misuse reuses benign persona
  names — a legitimate user, not an attacker.
- `args` — realistic parameters, not just the target asset. Misuse calls also
  carry a human-readable `_mistake` field.

## Result (from `dynamic_eval/SUMMARY.md`)

Misuse is its own class in the evaluation: baselines are learned from benign
sessions only, and misuse is scored, not used as "normal". By construction it
should land **between** benign and adversarial — it influences assets (scores
above benign) but carries no attack sequence (scores below adversarial). The
mean session band-rank confirms this ordering.

## Reproduce

```bash
uv run python scripts/make_dynamic_testbed.py    # regenerate the logs
uv run python scripts/evaluate_dynamic.py        # re-score the separation
```
