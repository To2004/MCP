# Live run — real MCP servers, real keys (benign-only)

Ran on 2026-07-06 on the HPC login node after installing Node (conda env
`mcpnode`) and loading the keys from `Keys.zip`. **Benign / read-only only** — no
create/update/push/delete/merge/fork tool was ever called (enforced by an
allowlist). This is the honest answer to "did it really run": one of the three
genuinely ran live end to end; the other two are blocked by the *credentials*,
not the framework.

## Result per server

| server | live? | evidence |
| --- | --- | --- |
| **GitHub** | ✅ **ran live** | Real `@modelcontextprotocol/server-github` started with the real `ghp_` token; advertised **26 tools**; `search_repositories` returned `total_count: 267`; `get_file_contents` returned the real `modelcontextprotocol/servers` README (sha `fe5351a…`, 8609 bytes). Captured in `github_captured.json`. |
| **Slack** | ❌ blocked (credential type) | Real `@modelcontextprotocol/server-slack` started and a **real read-only API call was made** — Slack replied `{"ok":false,"error":"invalid_auth"}`. The provided token is `xoxe.…` (a rotation/refresh token), not the bot token (`xoxb-`) the standard server needs. |
| **Google Calendar** | ❌ blocked (auth flow) | The key is an OAuth **installed-app** client (`client_id`/`client_secret`, no `refresh_token`). That flow needs interactive browser consent to mint a token — impossible headless on a login node. |

## What the GitHub run proves

1. **The end-to-end live path works**: real MCP server + real credential + real
   GitHub API + captured by the same tooling the framework uses.
2. **Real ≫ sample**: the real server exposes **26 tools** vs the **11** in the
   demo `github_cbg` scan — 16 tools (PR reviews, branches, issue comments, code
   search) the demo never modelled. The real catalog is saved to
   `reports/tool_lists/github_real.json` for a future real scan.
3. **The scorer stays honest on live data**: scoring the two real calls against
   the demo scan returns **`unresolved`** (the real repos were never scanned) —
   it refuses to fabricate a band, exactly as on synthetic data. To get real
   risk bands, scan `github_real.json` with the LLM scanner (GPU).

## To unblock Slack / Calendar

- **Slack**: exchange the `xoxe` rotation token for a bot token (`xoxb-`) via the
  OAuth refresh, or supply a bot token + `SLACK_TEAM_ID` directly.
- **Calendar**: run the OAuth consent once on a machine with a browser to obtain
  a `refresh_token`, then the calendar server can auth headless.

## Safety

- Read-only allowlist enforced; no state-changing tool was called.
- Keys were read from files, never hardcoded or printed; the decrypted copies
  under `~/.mcp_live_keys/` were shredded after the run. `Keys.zip` is `chmod 600`.
