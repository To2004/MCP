# All static scans (blast-1-5 / number-first pipeline) — 4 formats each

13 scans (3 real MCPs + 10 demo servers). Each scan is provided as:
  <stem>.json        full scanner output (source of truth)
  <stem>.md          human-readable: primitives, risk matrix, atomic ops, input ranking
  <stem>.xlsx        ordered workbook: RiskMatrix / Primitives / AtomicOps / InputRanking
  <stem>_matrix.csv  flat (asset, tool, score, band)

Current pipeline:
- **blast radius 1-5** (no "N/A"/0 cells — every (tool, asset) pair carries a real score)
- **judge off** (evaluation-only; primitives are the base model's, bands are the
  deterministic band_label(score) — reproducible)
- **bands are visualization-only**; the NUMBER (score = sensitivity*blast*impact) is
  the object of interest and drives call ranking (final_score = score*param_multiplier)
- every scan carries tool_atomic_ops (tool -> atomic op + severity) and
  tool_input_ranking (inputs ranked 1-5 + critical_trigger, e.g. "amount >= 100000")

Scan versions in this bundle: demo=scan-blast15, real=scan-real-2026-07-06.
(The 10 demo servers were re-scanned on the current pipeline; the 3 real MCPs are
the prior scan and are included for completeness.)
