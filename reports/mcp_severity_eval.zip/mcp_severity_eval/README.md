# MCP Risk-Scoring — Severity Evaluation Deliverable

Risk-SCORING (graded severity) evaluation vs CVSS/NIST/DREAD/OWASP AND vs AgentTrust's
own scorer, on external benchmarks (AgentTrust 430) + authored set (66) = 496 scenarios.

Start here:
- severity_eval/SUMMARY.md            — what was done, results, problems, head-to-head
- severity_eval/RELATED_VALIDATION.md — how others prove risk scores system-wise + comparables
- severity_eval/BENCHMARK_SEARCH.md   — benchmark hunt + why most don't fit
- severity_eval/severity_benchmark.md — per-source agreement tables (incl. AgentTrust column)
- severity_eval/severity_analysis.md  — confusion matrix, bias, worst failing cases

scripts/ (loader, our+CVSS/NIST/DREAD/OWASP scorers, AgentTrust runner, evaluator, analysis)
external/ (AgentTrust AGPL-3.0 + authored mcp_severity) · paper/ (LaTeX+PDF)
Reproduce: uv run python scripts/evaluate_severity.py ; analyze_severity.py
AgentTrust head-to-head: clone github.com/chenglin1112/AgentTrust, set AGENTTRUST_SRC,
  uv run --with pydantic --with rich --with httpx --with jinja2 python scripts/run_agenttrust_scorer.py
