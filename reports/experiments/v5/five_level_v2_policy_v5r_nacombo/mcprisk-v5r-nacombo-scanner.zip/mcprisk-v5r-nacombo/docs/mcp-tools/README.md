# MCP Tool References

Reference documentation for the MCP servers the thesis project studies and
scores. Two layers:

- **Catalog layer** — broad inventory across the MCP ecosystem
  (~120 servers across 16 asset domains).
- **Deep-doc layer** — per-tool reference for the four servers used as
  the live testbed.

## Catalog

| File | What's in it |
|------|--------------|
| [catalog.md](catalog.md) | Domain-categorized catalog of notable MCP servers. Each row: server, sample tools, link, evidence tag. |
| [domain-graph.md](domain-graph.md) | Two Mermaid views — domain → servers, and domain → operation types (linked to the atomic-op taxonomy). |
| [server-profiles.md](server-profiles.md) | Organizational profile for each of the 18 scanned servers: owning company, expected agent use, peak asset severity, and per-asset CIA emphasis. Profiles are written at five deliberate length tiers (XS–XL) so context length can be A/B'd as scanner input. |
| [server-policies.md](server-policies.md) | Policy-grade descriptions of 19 servers (5 fs tenants + github/slack/calendar real & cbg + 5 finance + 3 live-provisioned) — the realistic-disclosure variant: a data-classification table stating adverse impact per class, an asset register (asset · description · tools · flags · CIA) and recognition rules, with **no sensitivity number anywhere** (real orgs don't release the inventory). The scanner derives the 1–5 itself. Consumed by `scripts/scan_policy_v5.py`, `scripts/scan_policy_sens.py` and `scripts/scan_policy_no_sens.py`; validated by `scripts/check_policies.py`. |
| [server-profile-contents-proposal.md](server-profile-contents-proposal.md) | Worked L3 example (`sqlite:devops_sqlite`) — asset contents and sensitivity merged into one table, per the [profile spec](../standards/mcp-profile-spec.md). Proposal only; nothing reads it yet. |

## Deep references (per-server tool docs)

These four servers are used as the live testbed for the scoring framework
and have full per-tool documentation:

| Server | Tool reference | Upstream README |
|--------|----------------|-----------------|
| Filesystem | [filesystem.md](filesystem.md) | [filesystem-mcp-readme.md](filesystem-mcp-readme.md) |
| GitHub | [github.md](github.md) | [github-mcp-readme.md](github-mcp-readme.md) |
| Slack | [slack.md](slack.md) | [slack-mcp-readme.md](slack-mcp-readme.md) |
| SQLite | [sqlite.md](sqlite.md) | [sqlite-mcp-readme.md](sqlite-mcp-readme.md) |

## Live-provisioned organizations

The last three policy sections pair one organization with one **real** vendor
catalog — no demo surfaces:

| Section | Organization | Domain | Catalog |
|---|---|---|---|
| `github_helios` | Helios Grid | electricity transmission | real GitHub, 26 tools |
| `slack_vireo` | Vireo Bio | biopharmaceutical R&D | real Slack, 16 tools |
| `calendar_aurora` | Aurora Airways | commercial aviation | real Google Calendar, 13 tools |

Their register ids name assets that exist — created through the real MCP servers
on 2026-07-29 and read back through them. Provenance, the call captures and the
provisioning caveats:
[`reports/live_run/orgs_2026-07-29/`](../../reports/live_run/orgs_2026-07-29/README.md).

## Related

- [`../standards/atomic-op-classification.md`](../standards/atomic-op-classification.md) — operation taxonomy used by `domain-graph.md`.
- [`../standards/mcp-tool-risk-ratings.csv`](../standards/mcp-tool-risk-ratings.csv) — per-tool CVSS-style risk ratings.
- [`../project/annotated-bibliography-mcp-security.md`](../project/annotated-bibliography-mcp-security.md) — papers cited in the `paper-cited` evidence tag of the catalog.
