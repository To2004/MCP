#!/bin/bash
# Reproduce the nacombo scan from inside this bundle. No path here points outside it.
#
#   ./run_scan.sh                 # every server in the corpus
#   ./run_scan.sh sqlite_cbg_sqlite
#   NO_LLM=1 ./run_scan.sh calendar_real   # smoke test, no model needed
set -euo pipefail
BUNDLE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONPATH="$BUNDLE/src"
export OLLAMA_HOST="${OLLAMA_HOST:-http://127.0.0.1:11434}"
ARGS=(--impact-mode five_level_v2_v5r_nacombo --overwrite)
[ -n "${1:-}" ] && ARGS+=(--only "$1")
[ -n "${NO_LLM:-}" ] && ARGS+=(--no-llm)
exec python "$BUNDLE/scripts/scan_policy_v5.py" "${ARGS[@]}"
