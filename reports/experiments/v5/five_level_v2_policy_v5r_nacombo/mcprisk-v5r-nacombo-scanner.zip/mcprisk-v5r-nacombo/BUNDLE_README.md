# McpRisk v5r — `nacombo` arm, self-contained scanner bundle

Everything needed to reproduce the `nacombo` static scan. **Nothing here reads a
path outside this folder.** Unpack it anywhere.

## Run it

```bash
pip install -r requirements.txt          # requests, nothing else
./run_scan.sh                            # the whole corpus
./run_scan.sh sqlite_cbg_sqlite          # one server
NO_LLM=1 ./run_scan.sh calendar_real     # smoke test, no model needed
```

`run_scan.sh` expects an Ollama-compatible endpoint at `$OLLAMA_HOST`
(default `http://127.0.0.1:11434`). `run_scan.sbatch` starts one itself on a
SLURM node — set `OLLAMA_BIN` and `OLLAMA_MODELS` for your site.

Results land in `results/five_level_v2_policy_v5r_nacombo/`, alongside the copies
of the original run already there.

## What is in here

| Path | What it is |
|---|---|
| `scripts/scan_policy_v5.py` | the driver: one scan per server |
| `src/mcp_security/` | the scanner (28 Python files — the driver's full import closure) |
| `docs/mcp-tools/server-policies.md` | **the only org input the scanner reads** — classification classes, asset registers, recognition rules, and no risk numbers anywhere |
| `docs/standards/mcp-policy-spec.md` | what a conforming policy section must contain |
| `inputs/tool_catalogs/` | captured `tools/list` output per server |
| `inputs/finance_catalogs/` | the same, for the third-party finance servers (15 catalogs in total) |
| `inputs/ground_truth/server-profiles.md` | the org's own per-asset numbers — **held out**, see below |
| `results/` | the artifacts this arm produced: `.json`, `.md`, `.csv` per server |
| `results/.../scoring-prompts-AS-RUN.md` | every prompt the run sent, rendered |

## The two inputs, and the one thing that is held out

The scanner sees exactly two documents per server: the **tool catalog** and the
**organization's policy**. The policy states what classes of data the
organization recognises and what happens if each is lost — it never states a
number from 1 to 5. Every number in `results/` is derived.

`inputs/ground_truth/server-profiles.md` is the organization's own per-asset
sensitivity inventory. It is the answer key the derived numbers are scored
against, and the scan must never see it. It is stored here **deliberately not at
the path the code would look for it**, so a run in this bundle cannot read it
even by accident.

## How a score is built

Every cell is `sensitivity × blast × impact`, each 1–5, so 1–125.

| primitive | what it asks | who decides |
|---|---|---|
| **tool impact** | what one call *does* — read, write, remove | a deterministic ladder; the model only where the ladder abstains |
| **asset sensitivity** | how bad if this asset is lost | the model, classifying the asset against the org's own policy classes |
| **blast radius** | how far the consequences *propagate* | the model |

Each artifact records which of those two answered every tool
(`tool_impact_source`), the reasoning behind each number, and the SHA-256 of both
inputs (`catalog_sha256`, `profile_sha256`) so a rerun can be checked against it.

## Note on large catalogs

Servers with many tools (`maverick`, 119) can abort the CUDA flash-attention
kernel on some driver/model combinations — `ggml_abort` in `launch_fattn`, or
`CUDA error: an illegal memory access`. It is a kernel fault, not a scanner one.
Set `OLLAMA_FLASH_ATTENTION=0` for those runs.
