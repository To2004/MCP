# nacombo call corpus — bundle

Everything used to build the `five_level_v2_policy_v5r_nacombo` call corpus for
the three live-provisioned organizations, and every result produced. Three
servers: `github_helios` (26-tool GitHub), `slack_vireo` (16-tool Slack),
`calendar_aurora` (13-tool Google Calendar).

Category mix in every corpus: **50% BENIGN / 25% MISUSE / 25% MALICIOUS**,
chosen against each server's policy section.

## `runners/` — the scripts that create the calls

| File | Makes |
|---|---|
| `live_scale_run.py` | **1000 REAL live calls per org** (3000 total). Real-id discovery + fixtures, bounded+self-cleaning attacks. The main corpus. |
| `live_call_run.py` | the earlier **98 REAL live calls** end-to-end smoke corpus. |
| `make_synthetic_calls.py` | the **500 SYNTHETIC** calls for the 5 verbs that cannot run live. |

## `results/` — the produced calls

- `live_scale/` — the 3000 real calls: per-org CSVs + `live_scale_all.csv` +
  full transcript `live_scale_captured.json` + writeup `live_scale_run.md`.
  Every row `synthetic=false`.
- `live/` — the 98-call real run: `live_calls.csv`, `live_captured.json`,
  `live_run.md`.
- `synthetic_unusable/` — `unusable_tools_synth.csv` (500 rows, 100 each for
  `fork_repository`, `usergroups_create`/`_update`/`_users_update`,
  `respond-to-event`) + `TOOLS_UNUSABLE.md` explaining why each cannot run live.
  Every row `synthetic=true`, `status=SIMULATED`.

CSV schema (all):
`index,timestamp,org,persona,category,asset,tool,status,args,output,run_id,synthetic`

## `sources/` — inputs the calls were built from

- `server-policies.md` — the organizational policy document; its
  `github_helios` / `slack_vireo` / `calendar_aurora` sections define the asset
  registers and the benign/misuse/attack boundaries.
- `<org>.md` / `<org>.json` / `<org>_matrix.csv` — the static scan of each server
  (tool catalog, asset register, and design-time risk scores) that the call
  categories are scored against.
- `mcp_live.py` — the stdio JSON-RPC client used to drive the real MCP servers.
- `slack_channels.json`, `calendars.json`, `github_repos.json` — the real asset
  ids (channels, calendars, repositories) the live calls target.

## Reproduce

Real runs need the live MCP servers (Node env), a GitHub token via
`gh auth token` (scopes incl. `repo`, `delete_repo`), the Slack token in
`~/.mcp_live_keys/Keys/slackkey.txt`, and Google Calendar creds — none of which
are in this bundle. The synthetic set is fully offline:

```
python runners/make_synthetic_calls.py     # regenerates unusable_tools_synth.csv
python runners/live_scale_run.py all 1000   # 1000 real calls/org (needs live creds)
```

## Headline results

| Corpus | Calls | Mix | Status |
|---|---:|---|---|
| real scaled | 3000 | B1500 / M750 / A750 | 2998 OK, 2 transient ERROR |
| real smoke | 98 | B52 / M21 / A25 | 93 OK, 5 ERROR (the un-runnable verbs) |
| synthetic unusable | 500 | 100 × 5 verbs | SIMULATED |

All real attacks fired against To2004 sandbox assets and were cleaned up; post-run
audit found zero residual repos, issues, PRs, branches, files, or calendar events.
