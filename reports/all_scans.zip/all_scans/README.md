# All static scans — every MCP (clean pipeline), 4 formats each

13 scans (3 real MCPs + 10 demo servers). Each scan is provided as:
  <stem>.json        full scanner output (source of truth)
  <stem>.md          human-readable: primitives, risk matrix, atomic ops, input ranking
  <stem>.xlsx        ordered workbook: RiskMatrix (band-coloured) / Primitives / AtomicOps / InputRanking
  <stem>_matrix.csv  flat (asset, tool, score, band)

Clean pipeline: deterministic bands (band_label(score), reproducible), judge off,
blast 0-5. Every scan carries tool_atomic_ops (tool -> atomic op + severity) and
tool_input_ranking (inputs ranked 1-5 + critical_trigger e.g. "amount >= 100000").
