# Real MCP Risk Matrices — LLM Scans

LLM-derived (Qwen2.5:32b, strict/LLM-only) risk matrices for the **real** MCP
tool catalogs captured live, produced by `scripts/scan_real_catalogs.py` on a
GPU node (SLURM job 19087928, rtx_4090).

| MCP | tools | asset scopes | cells | bands (low/med/high/crit) |
| --- | --- | --- | --- | --- |
| GitHub | 26 | 6 repo scopes | 156 | 75 / 47 / 20 / 14 |
| Google Calendar | 13 | 6 calendar scopes | 78 | 18 / 16 / 30 / 14 |
| Slack | 16 | 10 channel scopes | 160 | 56 / 66 / 31 / 7 |

`provenance = llm-scan` on all three (not the deterministic offline baseline).

## Contents

```
scan/github_real.json    + .md     real risk matrix + markdown table
scan/calendar_real.json  + .md
scan/slack_real.json     + .md
tool_lists/github_real.json        the real tool catalogs these were scanned from
tool_lists/calendar_real.json
tool_lists/slack_real.json
```

## Honest scope note

The **tools** are the real captured catalogs (GitHub 26, Calendar 13, Slack 16 —
2–3× the demo). The **asset scopes** are each kind's representative set (repos /
calendars / channels) from the registry, not a live inventory of the specific
account — so tool-impact and per-cell reasoning are real, the asset set is
representative. Calendar skews high/critical because its scopes are uniformly
high-sensitivity (a known property of that scan).
