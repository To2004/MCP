# Full scanner output — one complete scan per MCP

The full static scan of each real MCP server, produced by the current pipeline
(deterministic bands, judge/LLM-band off, blast 0–5, atomic-op flags, LLM input
ranking + critical triggers). **One scan per MCP** — the scanner is per-server,
not per-org, so there is a single comprehensive artifact for each.

| MCP | server package | tools | asset scopes |
| --- | --- | --- | --- |
| GitHub | @modelcontextprotocol/server-github | 26 | 6 repo scopes |
| Google Calendar | @cocal/google-calendar-mcp | 13 | 6 calendar scopes |
| Slack | slack-mcp-server | 16 | 10 channel scopes |

## What each scan (`scan/<mcp>_real.json`) contains

The complete scanner output in one file:

- `tool_impact` (1–3), `asset_sensitivity` (1–5), `blast_radius` (0–5) — the
  three LLM-derived primitives.
- `cells` — the numeric risk score per (tool, asset) = sensitivity × blast × impact.
- `bands` — the deterministic `band_label(score)` (low/medium/high/critical),
  reproducible; a coarse floor the dynamic scorer consumes.
- `band_distribution` — the risk pyramid.
- `tool_atomic_ops` — every tool flagged to an atomic operation (EXECUTE…LIST) +
  severity, from the taxonomy.
- `tool_input_ranking` — each tool's inputs ranked 1–5 by risk, with a
  `critical_trigger` (e.g. `amount ≥ 100000`, `≥ 20 recipients`, `unbounded`).
- `crosscheck_summary: {judge_ran: false}`, provenance, kind.

## Contents

```
scan/github_real.json    + .md      full scan + human-readable table
scan/calendar_real.json  + .md
scan/slack_real.json     + .md
tool_lists/github_real.json          the real tool catalogs scanned
tool_lists/calendar_real.json
tool_lists/slack_real.json
```

## Honest scope note

Real tool catalogs (GitHub 26 / Calendar 13 / Slack 16) scanned against each
kind's representative asset scopes (repos / calendars / channels) — tool-impact
and per-cell reasoning are real; the asset set is representative, not a live
inventory of one account.
