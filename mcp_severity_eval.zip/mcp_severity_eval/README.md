# MCP Risk-Scoring — Severity Evaluation Deliverable

Evaluation of the MCP risk-scoring framework as a graded **severity** scorer (not
attack detection), head-to-head with CVSS / NIST 800-30 / DREAD / OWASP, on external
graded-severity benchmarks (AgentTrust, 430 items) + an authored MCP/ops set (66).

Start here:
- `severity_eval/SUMMARY.md`         — what was done, results, diagnosed problems
- `severity_eval/BENCHMARK_SEARCH.md`— the benchmark hunt + why most don't fit
- `severity_eval/severity_benchmark.md` — per-source agreement tables
- `severity_eval/severity_analysis.md`  — confusion matrix, bias, worst failing cases

Layout: scripts/ (loader, scorers, evaluator, analysis, metrics) · external/ (data:
AgentTrust AGPL-3.0 + authored mcp_severity) · paper/ (LaTeX + PDF).
Reproduce: uv run python scripts/evaluate_severity.py ; .../analyze_severity.py
